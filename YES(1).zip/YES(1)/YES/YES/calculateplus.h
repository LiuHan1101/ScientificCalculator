#ifndef CALCULATEPLUS_H
#define CALCULATEPLUS_H

#include <QWidget>
#include <QString>

namespace Ui {
class CalculatePlus;
}

class CalculatePlus : public QWidget
{
    Q_OBJECT

public:
    explicit CalculatePlus(QWidget *parent = nullptr);
    ~CalculatePlus();

signals:
    void backToMainRequested();

private slots:
    // 数字按钮
    void on_pushButton_0_clicked();
    void on_pushButton_1_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_7_clicked();
    void on_pushButton_8_clicked();
    void on_pushButton_9_clicked();

    // 运算符按钮
    void on_pushButton_plus_clicked();    // +
    void on_pushButton_minus_clicked();   // -
    void on_pushButton_multiply_clicked();// *
    void on_pushButton_divide_clicked();  // /
    void on_pushButton_equal_clicked();   // =
    void on_pushButton_clear_clicked();   // C
    void on_pushButton_dot_clicked();     // .
    void on_pushButton_backspace_clicked(); // ←

    // 功能按钮

    void on_pushButton_clicked();// 返回按钮

private:
    Ui::CalculatePlus *ui;

    // 计算器状态变量
    double currentValue;
    double storedValue;
    char lastOperator;
    bool waitingForOperand;
    QString currentInput;
    void appendNumber(const QString&digit);
    void handleOperator(char op);
    void calculateEnhanced();
    void updateDisplay();
    void resetCalculator();
    void performCalculation();
    void setCalculatorStyle();
};

#endif // CALCULATEPLUS_H
