#include "equation.h"
#include "ui_equation.h"
#include "linear.h"
#include "quadratic.h"
#include "equationset.h"
#include <QVBoxLayout>
#include <QDebug>

Equation::Equation(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::equation),
    linearPage(nullptr),
    quadraticPage(nullptr),
    binaryPage(nullptr)
{
    ui->setupUi(this);

    // 设置样式
    this->setStyleSheet("background-color: #f8f9fa;");
    this->setMinimumSize(600, 500);

    // 获取主布局
    QVBoxLayout *mainLayout = qobject_cast<QVBoxLayout*>(this->layout());

    // 创建方程页面
    linearPage = new Linear();
    quadraticPage = new Quadratic();
    binaryPage = new Equationset();

    // 将页面添加到布局中（默认隐藏）
    if (mainLayout) {
        mainLayout->addWidget(linearPage);
        mainLayout->addWidget(quadraticPage);
        mainLayout->addWidget(binaryPage);

        // 初始隐藏所有页面
        hideAllPages();
    }

    // 连接信号 - 只在这里连接一次
    connect(linearPage, &Linear::returnToEquationRequested, this, [this]() {
        qDebug() << "收到Linear返回方程选择信号";
        // 取消所有单选按钮的选择
        ui->radioButton->setAutoExclusive(false);
        ui->radioButton_2->setAutoExclusive(false);
        ui->radioButton_3->setAutoExclusive(false);

        ui->radioButton->setChecked(false);
        ui->radioButton_2->setChecked(false);
        ui->radioButton_3->setChecked(false);

        ui->radioButton->setAutoExclusive(true);
        ui->radioButton_2->setAutoExclusive(true);
        ui->radioButton_3->setAutoExclusive(true);

        hideAllPages();
    });

    connect(linearPage, &Linear::returnToMainRequested, this, &Equation::backToMainRequested);

    connect(quadraticPage, &Quadratic::returnToEquationRequested, this, [this]() {
        qDebug() << "收到Quadratic返回方程选择信号";
        // 取消所有单选按钮的选择
        ui->radioButton->setAutoExclusive(false);
        ui->radioButton_2->setAutoExclusive(false);
        ui->radioButton_3->setAutoExclusive(false);

        ui->radioButton->setChecked(false);
        ui->radioButton_2->setChecked(false);
        ui->radioButton_3->setChecked(false);

        ui->radioButton->setAutoExclusive(true);
        ui->radioButton_2->setAutoExclusive(true);
        ui->radioButton_3->setAutoExclusive(true);

        hideAllPages();
    });

    connect(quadraticPage, &Quadratic::returnToMainRequested, this, &Equation::backToMainRequested);

    connect(binaryPage, &Equationset::returnToEquationRequested, this, [this]() {
        qDebug() << "收到Equationset返回方程选择信号";
        // 取消所有单选按钮的选择
        ui->radioButton->setAutoExclusive(false);
        ui->radioButton_2->setAutoExclusive(false);
        ui->radioButton_3->setAutoExclusive(false);

        ui->radioButton->setChecked(false);
        ui->radioButton_2->setChecked(false);
        ui->radioButton_3->setChecked(false);

        ui->radioButton->setAutoExclusive(true);
        ui->radioButton_2->setAutoExclusive(true);
        ui->radioButton_3->setAutoExclusive(true);

        hideAllPages();
    });

    connect(binaryPage, &Equationset::returnToMainRequested, this, &Equation::backToMainRequested);

    // 连接UI中的返回主菜单按钮
    connect(ui->returnToMainButton, &QPushButton::clicked, this, &Equation::on_returnToMainButton_clicked);

    // 连接单选按钮信号
    connect(ui->radioButton, &QRadioButton::clicked, this, &Equation::on_radioButton_clicked);
    connect(ui->radioButton_2, &QRadioButton::clicked, this, &Equation::on_radioButton_2_clicked);
    connect(ui->radioButton_3, &QRadioButton::clicked, this, &Equation::on_radioButton_3_clicked);

    qDebug() << "Equation界面初始化完成";
}

Equation::~Equation()
{
    delete ui;
}

void Equation::on_returnToMainButton_clicked()
{
    qDebug() << "Equation页面：点击返回主菜单按钮";
    emit backToMainRequested();
}

void Equation::hideAllPages()
{
    if (linearPage) linearPage->hide();
    if (quadraticPage) quadraticPage->hide();
    if (binaryPage) binaryPage->hide();
}

void Equation::showEquationPage(QWidget *page)
{
    hideAllPages();
    if (page) {
        page->show();
    }
}

void Equation::on_radioButton_clicked()
{
    if (ui->radioButton->isChecked()) {
        showEquationPage(linearPage);
        qDebug() << "显示一元一次方程页面";
    } else {
        if (linearPage) linearPage->hide();
    }
}

void Equation::on_radioButton_2_clicked()
{
    if (ui->radioButton_2->isChecked()) {
        showEquationPage(quadraticPage);
        qDebug() << "显示一元二次方程页面";
    } else {
        if (quadraticPage) quadraticPage->hide();
    }

}

void Equation::on_radioButton_3_clicked()
{
    if (ui->radioButton_3->isChecked()) {
        showEquationPage(binaryPage);
        qDebug() << "显示二元一次方程组页面";
    } else {
        if (binaryPage) binaryPage->hide();
    }

}
