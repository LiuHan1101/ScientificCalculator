#include "linear.h"
#include "ui_linear.h"
#include <QRegularExpressionValidator>
#include <QMessageBox>
#include <cmath>
#include <QDebug>


Linear::Linear(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Linear)
{
    ui->setupUi(this);

    // 设置结果文本框为只读
    ui->result->setReadOnly(true);

    // 连接信号和槽
    connect(ui->pushButton, &QPushButton::clicked, this, &Linear::on_pushButton_clicked);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &Linear::on_pushButton_2_clicked);
    connect(ui->returnToEquationButton, &QPushButton::clicked, this, &Linear::on_returnToEquationButton_clicked);
    connect(ui->returnToMainButton, &QPushButton::clicked, this, &Linear::on_returnToMainButton_clicked);

    qDebug() << "Linear页面初始化完成";
}

Linear::~Linear()
{
    delete ui;
}



void Linear::on_pushButton_clicked()
{
    // 获取输入值
    QString aText = ui->aLineEdit->text();
    QString bText = ui->aLineEdit_2->text();

    // 检查输入是否为空
    if (aText.isEmpty() || bText.isEmpty()) {
        ui->result->setPlainText("错误：请输入所有系数！");
        return;
    }

    // 转换为double
    bool ok1, ok2;
    double a = aText.toDouble(&ok1);
    double b = bText.toDouble(&ok2);

    if (!ok1 || !ok2) {
        ui->result->setPlainText("错误：请输入有效的数字！");
        return;
    }

    // 检查a是否为0
    if (qFuzzyIsNull(a)) {
        ui->result->setPlainText("错误：系数a不能为0！");
        return;
    }

    // 开始构建结果文本，显示计算过程
    QString resultText;
    resultText.append("=== 一元一次方程求解过程 ===\n\n");
    resultText.append(QString("方程：%1x + %2 = 0\n\n").arg(a).arg(b));

    // 显示求解过程
    resultText.append("1. 移项：ax = -b\n");
    resultText.append(QString("   %1x = %2\n\n").arg(a).arg(-b));

    resultText.append("2. 求解：x = -b / a\n");
    double root = -b / a;

    resultText.append(QString("   x = %1 / %2\n").arg(-b).arg(a));
    resultText.append(QString("   x = %1\n\n").arg(root));

    resultText.append("=== 最终结果 ===\n");
    resultText.append(QString("x = %1").arg(root));

    // 显示结果
    ui->result->setPlainText(resultText);
    qDebug() << "求解一元一次方程完成";
}

void Linear::on_pushButton_2_clicked()
{
    // 清空所有输入和结果
    ui->aLineEdit->clear();
    ui->aLineEdit_2->clear();
    ui->result->clear();
    qDebug() << "清空输入和结果";
}

void Linear::on_returnToEquationButton_clicked()
{
    qDebug() << "Linear：请求返回方程选择页面";
    emit returnToEquationRequested();
}

void Linear::on_returnToMainButton_clicked()
{
    qDebug() << "Linear：请求返回主菜单";
    emit returnToMainRequested();
}
