#ifndef PDPTEST_H
#define PDPTEST_H

#include "qdialog.h"
#include "qlabel.h"
#include "qspinbox.h"
#include "ui_pdptest.h"
#include <QWidget>  // 主要修改：使用QWidget而不是QMainWindow
#include <QPlainTextEdit>
#include <streambuf>
#include <vector>
#include <string>
#include <map>
#include <exception>
#include <QShortcut>
#include <QDir>

// 前向声明
namespace Ui {
class PDPtest;
}


// 事件过滤器类（在头文件中声明）
class SpinBoxEnterKeyFilter : public QObject
{
    Q_OBJECT


public:
    SpinBoxEnterKeyFilter(std::function<void()> acceptCallback, QObject* parent = nullptr)
        : QObject(parent), m_acceptCallback(acceptCallback) {}

protected:
    bool eventFilter(QObject* obj, QEvent* event) override {
        if (event->type() == QEvent::KeyPress) {
            QKeyEvent* keyEvent = static_cast<QKeyEvent*>(event);
            if (keyEvent->key() == Qt::Key_Return || keyEvent->key() == Qt::Key_Enter) {
                m_acceptCallback();
                return true;
            }
        }
        return QObject::eventFilter(obj, event);
    }

private:
    std::function<void()> m_acceptCallback;
};



// 自定义异常类声明
class UserCanceledException : public std::exception {
public:
    const char* what() const noexcept override {
        return "用户取消了输入操作";
    }
};

// 问题结构体
struct Question {
    int id;
    std::string category;
    std::string text;
    int score;
};

// 类别结果结构体
struct CategoryResult {
    std::string name;
    int totalScore;
    std::vector<int> questionIds;
};

// 分析结果结构体
struct AnalysisResult {
    double average;
    int maxScore;
    int minScore;
    double standardDeviation;
    std::vector<int> maxIndices;
    std::vector<int> minIndices;
    bool hasDominantType;
    bool hasTwoStrongTypes;
    bool hasWeakType;
    bool isBalanced;
};

// 自定义输出流类，用于重定向 std::cout 到 QPlainTextEdit
class UICout : public std::streambuf {
private:
    QPlainTextEdit* m_textEdit;
    std::string m_buffer;

public:
    explicit UICout(QPlainTextEdit* textEdit);

protected:
    virtual int overflow(int ch) override;
    virtual int sync() override;
};

// 主测试类 - 保持继承QWidget
class PDPtest : public QWidget {
    Q_OBJECT

public:
    explicit PDPtest(QWidget *parent = nullptr);
    ~PDPtest();

    // 输入函数声明
    int getInputFromDialog(const QString& prompt, int minValue, int maxValue);

signals:
    void backToMainRequested();

private slots:
    // 按钮点击事件槽函数
    void on_selfTestButton_clicked();
    void on_workTestButton_clicked();
    void on_clearButton_clicked();
    void on_exitButton_clicked();

    void on_commandLinkButton_clicked();

private:
    Ui::PDPtest *ui;
    UICout* m_uiCout;
    std::streambuf* m_oldCoutBuffer;

    // 文件操作相关方法
    std::vector<Question> readQuestionsFromCSV(const std::string& filename);
    bool createSampleCSVFile(const QString& filename);
    std::vector<Question> createSampleQuestions();

    // 测试流程相关方法
    void conductSurvey(std::vector<Question>& questions);
    std::vector<CategoryResult> calculateCategoryScores(const std::vector<Question>& questions);
    AnalysisResult analyzeScores(const std::vector<CategoryResult>& results);
    void displayPersonalityResults(const std::vector<CategoryResult>& results, const AnalysisResult& analysis);
    void checkDataFiles();
    // 用户交互相关方法
    void explain();
    void handleUserCancel();

    // 测试功能方法
    void selftest();
    void worktest();
};

#endif // PDPTEST_H
