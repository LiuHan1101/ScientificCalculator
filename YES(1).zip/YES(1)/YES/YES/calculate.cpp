#include "calculate.h"
#include "calculateplus.h"
#include "ui_calculate.h"
#include "widget.h"
#include <iostream>
using namespace std;

int calculateMenu();
int PDPtext();
int BMItext();
int Equation();
int PhysicalFitnessTest();
int GradePoint();


#include "calculate.h"
#include "ui_calculate.h"
#include "calculateplus.h"

calculate::calculate(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::calculate)
    , subPageStack(nullptr)
    , basicCalcPage(nullptr)
    , calcPlusPage(nullptr)
{
    ui->setupUi(this);

    // 创建子页面堆叠窗口
    subPageStack = new QStackedWidget(this);

    // 创建子页面

    calcPlusPage = new CalculatePlus();

    // 连接子页面的返回信号

    connect(calcPlusPage, &CalculatePlus::backToCalculateRequested, this, &calculate::showCalculatePage);

    // 添加子页面到堆叠窗口

    subPageStack->addWidget(calcPlusPage);

    // 重新排列布局 - 只调整按钮顺序
    QVBoxLayout *mainLayout = new QVBoxLayout(this);

    // 按正确顺序添加按钮
     // 基础四则运算
    mainLayout->addWidget(ui->radioButton_3);  // 连续四则运算
    mainLayout->addWidget(ui->pushButton_2);  // 返回主菜单（最后）
    mainLayout->addWidget(subPageStack);

    // 初始隐藏子页面堆叠窗口
    subPageStack->setVisible(false);
}

calculate::~calculate()
{
    delete ui;
}

void calculate::showCalculatePage()
{
    subPageStack->setVisible(false);
    ui->pushButton_2->setVisible(true);
    ui->radioButton_3->setVisible(true);
}



void calculate::on_radioButton_3_clicked()
{
    subPageStack->setCurrentWidget(calcPlusPage);
    subPageStack->setVisible(true);
    ui->pushButton_2->setVisible(false);
    ui->radioButton_3->setVisible(false);

}



// 全局变量，用于控制菜单循环
bool returnToMainMenu = false;


// 主菜单中的四则运算选择
int calculateMenu() {// 四则运算功能

    while(true) {
        cout << "\n=== 四则运算功能 ===" << endl;
        cout << "请选择计算模式：" << endl;
        cout << "1. 基础四则运算" << endl;
        cout << "2. 连续四则运算" << endl;
        cout << "3. 返回主菜单" << endl;

        int choice;
        cout << "请输入选择 (1-3): ";
        cin >> choice;

        switch(choice) {
        case 1:
            CalculatePlus();
            break;
        case 2:
            CalculatePlus();
            break;
        case 3:
        {
            cout << "按回车键确定" << endl;
            return 1;
            // 返回主菜单
        default:
        {cout << "无效选择！" << endl;
            cout << "\n是否继续使用四则运算？(y/n): ";
            char continueChoice;
            cin >> continueChoice;
            if(continueChoice == 'y' || continueChoice == 'Y') {
                break; }// 返回主菜单
            else if (continueChoice == 'n' || continueChoice == 'N') {
                cout<<"请按回车键确认"<<endl;
                return 1;}
            // 返回主菜单
            else
            {
                cout<<"输入错误，将默认为您返回主菜单"<<endl;
                cout<<"请按回车键确认"<<endl;
                return 1;
            };
        };


            return -1; // 返回主菜单
        }
        }}}

int PDPtext() {
    cout << "职业人格测试功能" << endl;
    return 2;
}

int BMItext() {
    cout << "BMI评估功能" << endl;
    return 3;
}

int Equation() {
    cout << "解方程功能" << endl;
    return 4;
}

int PhysicalFitnessTest() {
    cout << "体测成绩计算功能" << endl;
    return 5;
}

int GradePoint() {
    cout << "绩点计算功能" << endl;
    return -1;
}

class MenuSystem {
private:
    bool running = true;

public:
    void showMainMenu() {
        cout << "\n========== 多功能计算器 ==========" << endl;
        cout << "请选择您想使用的功能：" << endl;
        cout << "1. 四则运算" << endl;
        cout << "2. 职业人格测试" << endl;
        cout << "3. 评估身体质量指数(BMI)" << endl;
        cout << "4. 解方程" << endl;
        cout << "5. 计算体测成绩" << endl;
        cout << "6. 计算绩点" << endl;
        cout << "0. 退出程序" << endl;
        cout << "请输入选择 (0-6): ";
    }

    void run() {
        while(running) {
            showMainMenu();
            int n;
            cin >> n;
            switch(n) {
            case 0:
                cout << "感谢使用，再见！" << endl;
                running = false;
                break;
            case 1:
                calculateMenu();
                break;
            case 2:
                PDPtext();
                break;
            case 3:
                BMItext();
                break;
            case 4:
                Equation();
                break;
            case 5:
                PhysicalFitnessTest();
                break;
            case 6:
                GradePoint();
                break;
            default:
                cout << "请在规定范围内输入有效数字！" << endl;
                break;
            };

            // 如果不是退出，暂停一下让用户看到结果
            if(running && n != 0) {
                cin.get();
                cin.ignore();
            }
        }
    }
};



int main() {
    MenuSystem menu;
    menu.run();
    return 0;
}



void calculate::on_pushButton_clicked()
{
    this->close();
    Widget *w =new Widget();
    w->show();
}

void calculate::on_pushButton_2_clicked()
{

    emit backToMainRequested();
    //this->close();
    //Widget w =new Widget();
    //w.show();

}
