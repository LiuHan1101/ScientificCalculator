#include "quadratic.h"
#include "ui_quadratic.h"
#include <QRegularExpressionValidator>
#include <QMessageBox>
#include <cmath>
#include <QDebug>


Quadratic::Quadratic(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Quadratic)
{
    ui->setupUi(this);


    // 设置结果文本框为只读
    ui->result->setReadOnly(true);

    // 连接信号和槽
    connect(ui->pushButton, &QPushButton::clicked, this, &Quadratic::on_pushButton_clicked);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &Quadratic::on_pushButton_2_clicked);
    connect(ui->pushButton_3, &QPushButton::clicked, this, &Quadratic::on_pushButton_3_clicked);
    connect(ui->pushButton_4, &QPushButton::clicked, this, &Quadratic::on_pushButton_4_clicked);

    qDebug() << "Quadratic页面初始化完成";
}

Quadratic::~Quadratic()
{
    delete ui;
}


void Quadratic::on_pushButton_clicked()
{
    // 获取输入值
    QString aText = ui->aLineEdit->text();
    QString bText = ui->bLineEdit->text();
    QString cText = ui->cLineEdit->text();

    // 检查输入是否为空
    if (aText.isEmpty() || bText.isEmpty() || cText.isEmpty()) {
        ui->result->setPlainText("错误：请输入所有系数！");
        return;
    }

    // 转换为double
    bool ok1, ok2, ok3;
    double a = aText.toDouble(&ok1);
    double b = bText.toDouble(&ok2);
    double c = cText.toDouble(&ok3);

    if (!ok1 || !ok2 || !ok3) {
        ui->result->setPlainText("错误：请输入有效的数字！");
        return;
    }

    // 检查a是否为0
    if (qFuzzyIsNull(a)) {
        ui->result->setPlainText("错误：系数a不能为0！");
        return;
    }

    // 开始构建结果文本，显示计算过程
    QString resultText;
    resultText.append("=== 一元二次方程求解过程 ===\n\n");
    resultText.append(QString("方程：%1x² + %2x + %3 = 0\n\n").arg(a).arg(b).arg(c));

    // 显示判别式计算过程
    resultText.append("1. 计算判别式 Δ = b² - 4ac\n");
    double discriminant = b * b - 4 * a * c;
    resultText.append(QString("   Δ = (%1)² - 4×(%2)×(%3)\n").arg(b).arg(a).arg(c));
    resultText.append(QString("   Δ = %1 - %2\n").arg(b*b).arg(4*a*c));
    resultText.append(QString("   Δ = %1\n\n").arg(discriminant));

    if (discriminant > 0) {
        // 两个实根
        resultText.append("2. 判别式 Δ > 0，方程有两个不相等的实根\n");
        resultText.append("   求根公式：x = (-b ± √Δ) / (2a)\n\n");

        double root1 = (-b + sqrt(discriminant)) / (2 * a);
        double root2 = (-b - sqrt(discriminant)) / (2 * a);

        resultText.append(QString("   x₁ = (-(%1) + √%2) / (2×%3)\n").arg(b).arg(discriminant).arg(a));
        resultText.append(QString("      = (%1 + %2) / %3\n").arg(-b).arg(sqrt(discriminant)).arg(2*a));
        resultText.append(QString("      = %1\n\n").arg(root1, 0, 'f', 6));

        resultText.append(QString("   x₂ = (-(%1) - √%2) / (2×%3)\n").arg(b).arg(discriminant).arg(a));
        resultText.append(QString("      = (%1 - %2) / %3\n").arg(-b).arg(sqrt(discriminant)).arg(2*a));
        resultText.append(QString("      = %1\n\n").arg(root2, 0, 'f', 6));

        resultText.append("=== 最终结果 ===\n");
        resultText.append(QString("x₁ = %1\n").arg(root1, 0, 'f', 6));
        resultText.append(QString("x₂ = %1").arg(root2, 0, 'f', 6));

    } else if (qFuzzyIsNull(discriminant)) {
        // 一个实根
        resultText.append("2. 判别式 Δ = 0，方程有两个相等的实根\n");
        resultText.append("   求根公式：x = -b / (2a)\n\n");

        double root = -b / (2 * a);

        resultText.append(QString("   x = -(%1) / (2×%2)\n").arg(b).arg(a));
        resultText.append(QString("     = %1 / %2\n").arg(-b).arg(2*a));
        resultText.append(QString("     = %1\n\n").arg(root, 0, 'f', 6));

        resultText.append("=== 最终结果 ===\n");
        resultText.append(QString("x₁ = x₂ = %1").arg(root, 0, 'f', 6));

    } else {
        // 两个虚根
        resultText.append("2. 判别式 Δ < 0，方程有两个共轭虚根\n");
        resultText.append("   求根公式：x = (-b ± √(-Δ)i) / (2a)\n\n");

        double realPart = -b / (2 * a);
        double imaginaryPart = sqrt(-discriminant) / (2 * a);

        resultText.append(QString("   实部 = -b / (2a) = -(%1) / (2×%2) = %3\n").arg(b).arg(a).arg(realPart, 0, 'f', 6));
        resultText.append(QString("   虚部 = √(-Δ) / (2a) = √%1 / %2 = %3\n\n").arg(-discriminant).arg(2*a).arg(imaginaryPart, 0, 'f', 6));

        resultText.append("=== 最终结果 ===\n");
        resultText.append(QString("x₁ = %1 + %2i\n").arg(realPart, 0, 'f', 6).arg(imaginaryPart, 0, 'f', 6));
        resultText.append(QString("x₂ = %1 - %2i").arg(realPart, 0, 'f', 6).arg(imaginaryPart, 0, 'f', 6));
    }

    // 显示结果
    ui->result->setPlainText(resultText);
    qDebug() << "求解一元二次方程完成";
}

void Quadratic::on_pushButton_2_clicked()
{
    // 清空所有输入和结果
    ui->aLineEdit->clear();
    ui->bLineEdit->clear();
    ui->cLineEdit->clear();
    ui->result->clear();
    qDebug() << "清空输入和结果";
}

void Quadratic::on_pushButton_3_clicked()
{
    qDebug() << "Quadratic：请求返回方程选择页面";
    emit returnToEquationRequested();
}

void Quadratic::on_pushButton_4_clicked()
{
    qDebug() << "Quadratic：请求返回主菜单";
    emit returnToMainRequested();
}
