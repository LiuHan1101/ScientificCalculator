#include "gpa.h"
#include "ui_gpa.h"
#include <QMessageBox>
#include <QDebug>
#include <QTableWidgetItem>

Gpa::Gpa(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Gpa)
{
    ui->setupUi(this);

    // 设置窗口属性
    this->setWindowTitle("绩点计算");


    // 初始化表格 - 设置7列
    ui->tableWidget->setColumnCount(7);
    QStringList headers;
    headers << "序号" << "课程名称" << "课程类型" <<"成绩" << "绩点" << "等级" << "课程学分";
    ui->tableWidget->setHorizontalHeaderLabels(headers);

    // 设置表格属性
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->horizontalHeader()->setStretchLastSection(true);

    // 初始化课程类型下拉框 - 只需要必修课和选修课
    ui->comboBox->clear();
    ui->comboBox->addItem("必修课");
    ui->comboBox->addItem("选修课");


    updateCourseCount();

    qDebug() << "GPA页面初始化完成";
}

Gpa::~Gpa()
{
    delete ui;
}

void Gpa::on_pushButton_clicked()  // 添加课程（将信息放入表格）
{
    QString courseName = ui->lineEdit->text();      // 课程名称
    QString courseType = ui->comboBox->currentText(); // 课程类型
    QString creditStr = ui->lineEdit_2->text();     // 学分
    QString gradeStr = ui->lineEdit_3->text();      // 成绩

    // 验证输入
    if (courseName.isEmpty() || creditStr.isEmpty() || gradeStr.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请填写课程名称、学分和成绩！");
        return;
    }

    bool creditOk, gradeOk;
    double credit = creditStr.toDouble(&creditOk);
    double grade = gradeStr.toDouble(&gradeOk);

    if (!creditOk || !gradeOk) {
        QMessageBox::warning(this, "输入错误", "学分和成绩必须是数字！");
        return;
    }

    if (credit <= 0) {
        QMessageBox::warning(this, "输入错误", "学分必须大于0！");
        return;
    }

    if (grade < 0 || grade > 100) {
        QMessageBox::warning(this, "输入错误", "成绩必须在0-100之间！");
        return;
    }

    // 计算等级和绩点
    QString level;
    double gradePoint = calculateGradePoint(grade, level);

    // 添加到表格 - 7列数据
    int row = ui->tableWidget->rowCount();
    ui->tableWidget->insertRow(row);

    // 序号（自动生成）
    ui->tableWidget->setItem(row, 0, new QTableWidgetItem(QString::number(row + 1)));
    // 课程名称
    ui->tableWidget->setItem(row, 1, new QTableWidgetItem(courseName));
    // 课程类型
    ui->tableWidget->setItem(row, 2, new QTableWidgetItem(courseType));
    // 成绩
    ui->tableWidget->setItem(row, 3, new QTableWidgetItem(QString::number(grade)));
    // 绩点
    ui->tableWidget->setItem(row, 4, new QTableWidgetItem(QString::number(gradePoint, 'f', 1)));
    // 等级
    ui->tableWidget->setItem(row, 5, new QTableWidgetItem(level));
    // 课程学分
    ui->tableWidget->setItem(row, 6, new QTableWidgetItem(QString::number(credit)));

    updateCourseCount();

    qDebug() << "添加课程到表格：" << courseName << "类型：" << courseType << "学分：" << credit << "成绩：" << grade;
}

void Gpa::on_addNewCourse_clicked()  // 添加新课程（清空输入字段，准备输入新课程）
{
    clearInputFields();
    qDebug() << "清空输入字段，准备添加新课程";
}

void Gpa::on_calculateAllGPA_clicked()  // 计算所有课程平均绩点
{
    int rowCount = ui->tableWidget->rowCount();
    if (rowCount == 0) {
        QMessageBox::information(this, "提示", "请先添加课程！");
        return;
    }

    double totalGradePoints = 0.0;
    double totalCredits = 0.0;

    for (int i = 0; i < rowCount; ++i) {
        double credit = ui->tableWidget->item(i, 6)->text().toDouble();
        double gradePoint = ui->tableWidget->item(i, 4)->text().toDouble();

        totalGradePoints += credit * gradePoint;
        totalCredits += credit;
    }

    double gpa = (totalCredits > 0) ? totalGradePoints / totalCredits : 0.0;

    QString result = QString("所有课程统计：\n课程总数：%1门\n总学分：%2\n平均绩点：%3")
                         .arg(rowCount)
                         .arg(totalCredits)
                         .arg(gpa, 0, 'f', 2);
    QMessageBox::information(this, "所有课程GPA计算结果", result);
}

void Gpa::on_calculateRequiredGPA_clicked()  // 计算必修课平均绩点
{
    calculateSpecificGPA("必修课");
}

void Gpa::on_calculateElectiveGPA_clicked()  // 计算选修课平均绩点
{
    calculateSpecificGPA("选修课");
}

void Gpa::calculateSpecificGPA(const QString &courseType)
{
    int rowCount = ui->tableWidget->rowCount();
    if (rowCount == 0) {
        QMessageBox::information(this, "提示", "请先添加课程！");
        return;
    }

    double totalGradePoints = 0.0;
    double totalCredits = 0.0;
    int courseCount = 0;

    for (int i = 0; i < rowCount; ++i) {
        QString type = ui->tableWidget->item(i, 2)->text();

        if (type == courseType) {
            double credit = ui->tableWidget->item(i, 6)->text().toDouble();
            double gradePoint = ui->tableWidget->item(i, 4)->text().toDouble();

            totalGradePoints += credit * gradePoint;
            totalCredits += credit;
            courseCount++;
        }
    }

    if (courseCount == 0) {
        QMessageBox::information(this, "提示", QString("没有找到%1课程！").arg(courseType));
        return;
    }

    double gpa = (totalCredits > 0) ? totalGradePoints / totalCredits : 0.0;

    // 直接在这里显示结果
    QString result = QString("%1统计：\n课程数量：%2门\n总学分：%3\n平均绩点：%4")
                         .arg(courseType)
                         .arg(courseCount)
                         .arg(totalCredits)
                         .arg(gpa, 0, 'f', 2);
    QMessageBox::information(this, QString("%1 GPA计算结果").arg(courseType), result);

    qDebug() << courseType << "GPA计算：" << gpa << "课程数量：" << courseCount << "总学分：" << totalCredits;
}

void Gpa::on_clearAll_clicked()  // 清空并重新开始
{
    int rowCount = ui->tableWidget->rowCount();
    if (rowCount == 0) return;

    int ret = QMessageBox::question(this, "确认清空",
                                    "确定要清空所有课程数据吗？",
                                    QMessageBox::Yes | QMessageBox::No);

    if (ret == QMessageBox::Yes) {
        ui->tableWidget->setRowCount(0);
        clearInputFields();
        updateCourseCount();
        qDebug() << "已清空所有课程数据";
    }
}

void Gpa::on_returnToMain_clicked()  // 返回主菜单
{
    qDebug() << "GPA页面：发射返回主菜单信号";
    emit backToMainRequested();
}

double Gpa::calculateGradePoint(double grade, QString &level)
{
    if (grade >= 90) {
        level = "A";
        return 4.0;
    } else if (grade >= 85) {
        level = "A-";
        return 3.7;
    } else if (grade >= 82) {
        level = "B+";
        return 3.3;
    } else if (grade >= 78) {
        level = "B";
        return 3.0;
    } else if (grade >= 75) {
        level = "B-";
        return 2.7;
    } else if (grade >= 72) {
        level = "C+";
        return 2.3;
    } else if (grade >= 68) {
        level = "C";
        return 2.0;
    } else if (grade >= 64) {
        level = "C-";
        return 1.7;
    } else if (grade >= 60) {
        level = "D";
        return 1.0;
    } else {
        level = "F";
        return 0.0;
    }
}

void Gpa::updateCourseCount()
{
    int count = ui->tableWidget->rowCount();
    ui->label_7->setText(QString("当前已录入%1门课程").arg(count));
}

void Gpa::clearInputFields()
{
    ui->lineEdit->clear();      // 清空课程名称
    ui->lineEdit_2->clear();    // 清空学分
    ui->lineEdit_3->clear();    // 清空成绩
}
