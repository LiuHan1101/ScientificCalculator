#include "pdptest.h"
#include "qdialogbuttonbox.h"
#include "qlabel.h"
#include "qspinbox.h"
#include "ui_pdptest.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <cmath>
#include <QScrollBar>
#include <QMetaObject>
#include <QInputDialog>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QStringConverter>
#include "widget.h"
#include <QShortcut>
#include <QDir>


using namespace std;

// UICout 类的实现
UICout::UICout(QPlainTextEdit* textEdit)
    : m_textEdit(textEdit)
{
}

int UICout::overflow(int ch)
{
    if (ch != traits_type::eof()) {
        m_buffer += static_cast<char>(ch);
        if (ch == '\n') {
            sync();
        }
    }
    return ch;
}

int UICout::sync()
{
    if (m_textEdit && !m_buffer.empty()) {
        // 使用 invokeMethod 确保线程安全
        QMetaObject::invokeMethod(m_textEdit, [this]() {
            // 追加文本到 QPlainTextEdit
            m_textEdit->appendPlainText(QString::fromStdString(m_buffer));

            // 自动滚动到底部
            QScrollBar* scrollbar = m_textEdit->verticalScrollBar();
            scrollbar->setValue(scrollbar->maximum());
        });

        m_buffer.clear();
    }
    return 0;
}

// PDPtest 类的实现
PDPtest::PDPtest(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::PDPtest)
    , m_uiCout(nullptr)
    , m_oldCoutBuffer(nullptr)
{
    ui->setupUi(this);



    QShortcut* shortcut1 = new QShortcut(QKeySequence(Qt::Key_1), this);

    connect(shortcut1, &QShortcut::activated, this, &::PDPtest::on_selfTestButton_clicked);

    QShortcut* shortcut2 = new QShortcut(QKeySequence(Qt::Key_2), this);

    connect(shortcut2, &QShortcut::activated, this, &::PDPtest::on_workTestButton_clicked);

    QShortcut* shortcut3 = new QShortcut(QKeySequence(Qt::Key_Backspace), this);

    connect(shortcut3, &QShortcut::activated, this, &::PDPtest::on_commandLinkButton_clicked);

    // 调试信息
    std::cout << "应用程序目录: " << QCoreApplication::applicationDirPath().toStdString() << std::endl;
    std::cout << "当前工作目录: " << QDir::currentPath().toStdString() << std::endl;

    // 检查数据文件
    checkDataFiles();

    // 设置默认字体，避免缺失字体警告
    QFont defaultFont("Microsoft YaHei UI", 9);  // 使用系统中文字体
    this->setFont(defaultFont);

    // 设置窗口标题
    this->setWindowTitle("PDP性格测试系统");

    // 设置 QPlainTextEdit 的属性
    ui->textOutput->setReadOnly(true);
    ui->textOutput->setMaximumBlockCount(1000);

    // 设置输出文本框的字体
    QFont textOutputFont("Microsoft YaHei UI", 9);  // 使用等宽字体
    ui->textOutput->setFont(textOutputFont);

    // 创建 UICout 并重定向 std::cout
    m_uiCout = new UICout(ui->textOutput);
    m_oldCoutBuffer = std::cout.rdbuf(m_uiCout);

    std::cout << "=== PDP性格测试系统 ===" << std::endl;
    std::cout << "系统初始化完成！请选择测试类型。" << std::endl;
    std::cout << "=================================" << std::endl;
}
//解析函数
PDPtest::~PDPtest(){
    // 恢复原来的 std::cout 缓冲区
    if (m_oldCoutBuffer) {
        std::cout.rdbuf(m_oldCoutBuffer);
    }
    delete m_uiCout;
    delete ui;
}

// 添加检查数据文件函数
void PDPtest::checkDataFiles()
{
    QStringList filesToCheck = {"questions.csv", "questions2.csv", "data/questions.csv", "data/questions2.csv"};

    for (const QString& filePath : filesToCheck) {
        QFile file(filePath);
        if (file.exists()) {
            std::cout << "找到文件: " << filePath.toStdString() << std::endl;
        } else {
            std::cout << "未找到文件: " << filePath.toStdString() << std::endl;
        }
    }
}

//输入对话框设置
int PDPtest::getInputFromDialog(const QString& prompt, int minValue, int maxValue)
{
    QDialog dialog(this);
    dialog.setWindowTitle("输入评分");
    dialog.setFixedSize(350, 150);

    QVBoxLayout* layout = new QVBoxLayout(&dialog);

    // 提示标签
    QLabel* label = new QLabel(prompt + QString(" (%1-%2)").arg(minValue).arg(maxValue), &dialog);
    label->setAlignment(Qt::AlignCenter);
    layout->addWidget(label);

    // 数字输入框
    QSpinBox* spinBox = new QSpinBox(&dialog);
    spinBox->setRange(minValue, maxValue);
    spinBox->setValue(minValue);
    spinBox->setFocus();
    spinBox->selectAll();
    layout->addWidget(spinBox);

    // 按钮布局
    QHBoxLayout* buttonLayout = new QHBoxLayout();

    QPushButton* cancelButton = new QPushButton("取消测试 (Esc)", &dialog);
    cancelButton->setStyleSheet("background-color: #8A9A9A; color: white; padding: 8px 16px;");

    QPushButton* okButton = new QPushButton("确认评分 (Enter)", &dialog);
    okButton->setStyleSheet("background-color: #F0D8D5; color: #7A8A9A; padding: 8px 16px;");
    okButton->setDefault(true);

    buttonLayout->addStretch();
    buttonLayout->addWidget(cancelButton);
    buttonLayout->addWidget(okButton);
    layout->addLayout(buttonLayout);

    // 使用枚举来区分不同的关闭原因
    enum DialogResult { Accepted, Canceled, UserCanceled };
    DialogResult dialogResult = Accepted;
    int result = minValue;

    auto acceptDialog = [&]() {
        result = spinBox->value();
        dialogResult = Accepted;
        dialog.accept();
    };

    auto rejectDialog = [&]() {
        dialogResult = Canceled;
        dialog.reject();
    };

    auto userCancelDialog = [&]() {
        dialogResult = UserCanceled;
        dialog.reject();
    };

    connect(okButton, &QPushButton::clicked, acceptDialog);
    connect(cancelButton, &QPushButton::clicked, rejectDialog);

    // 使用快捷键
    QShortcut* enterShortcut = new QShortcut(QKeySequence(Qt::Key_Return), &dialog);
    QShortcut* escapeShortcut = new QShortcut(QKeySequence(Qt::Key_Escape), &dialog);

    connect(enterShortcut, &QShortcut::activated, acceptDialog);
    connect(escapeShortcut, &QShortcut::activated, rejectDialog);

    // 居中显示
    dialog.move(600,600);

    // 显示对话框
    dialog.exec();

    // 对话框关闭后，根据结果进行处理
    if (dialogResult == UserCanceled) {
        // 用户取消测试，需要抛出异常
        handleUserCancel();
       throw UserCanceledException();


    }
    else if (dialogResult == Canceled) {
        // 普通取消（比如按Esc），也视为用户取消
        handleUserCancel();
    throw UserCanceledException();
    }
    else if (dialogResult == Accepted) {
        // 用户确认评分，返回结果
        return result;
    }

    // 默认情况（理论上不会执行到这里）
    handleUserCancel();
     throw UserCanceledException();
}

// 处理用户取消操作
void PDPtest::handleUserCancel()
{
    std::cout << "感谢使用PDP性格测试系统！" << std::endl;
    this->close();

}

// 创建示例CSV文件
bool PDPtest::createSampleCSVFile(const QString& filename) {
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        return false;
    }

    QTextStream out(&file);
    out.setEncoding(QStringConverter::System);

    // 写入标题行
    out << "ID,Category,QuestionText\n";

    // 写入示例问题
    vector<QString> categories = {"孔雀型", "考拉型", "老虎型", "猫头鹰型", "变色龙型"};
    for (int i = 0; i < 20; i++) {
        QString category = categories[i % 5];
        out << i + 1 << "," << category << ",\"示例问题 " << i + 1 << ": 请评价此项特质\"\n";
    }

    file.close();
    return true;
}

// 创建示例问题数据
vector<Question> PDPtest::createSampleQuestions() {
    vector<Question> questions;
    vector<string> categories = {"孔雀型", "考拉型", "老虎型", "猫头鹰型", "变色龙型"};

    for (int i = 0; i < 20; i++) {
        Question q;
        q.id = i + 1;
        q.category = categories[i % 5];
        q.text = "示例问题 " + to_string(i + 1) + ": 请评价此项特质";
        q.score = 0;
        questions.push_back(q);
    }

    return questions;
}


// 从CSV文件读取问题

vector<Question> PDPtest::readQuestionsFromCSV(const string& filename) {
    vector<Question> questions;

    if (filename.empty()) {
        std::cout << "文件名不能为空，使用示例数据。" << std::endl;
        return createSampleQuestions();
    }

    QString qFilename = QString::fromStdString(filename);

    // 调试信息：显示尝试的文件路径
    std::cout << "尝试打开文件: " << qFilename.toStdString() << std::endl;

    // 检查文件是否存在
    QFile file(qFilename);
    if (!file.exists()) {
        std::cout << "文件不存在: " << qFilename.toStdString() << std::endl;

        // 尝试在data目录下查找
        QString dataPath = "data/" + qFilename;
        file.setFileName(dataPath);
        std::cout << "尝试在data目录下查找: " << dataPath.toStdString() << std::endl;

        if (!file.exists()) {
            std::cout << "data目录下也不存在，创建示例文件。" << std::endl;
            if (!createSampleCSVFile(qFilename)) {
                std::cout << "创建示例文件失败，使用示例数据。" << std::endl;
                return createSampleQuestions();
            }
            file.setFileName(qFilename);
        }
    }

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        std::cout << "无法打开文件: " << file.fileName().toStdString() << std::endl;
        std::cout << "错误信息: " << file.errorString().toStdString() << std::endl;
        return createSampleQuestions();
    }

    std::cout << "成功打开文件: " << file.fileName().toStdString() << std::endl;

    QTextStream in(&file);
    in.setEncoding(QStringConverter::System);  // 改为UTF-8编码

    // 读取标题行
    QString header = in.readLine();
    if (header.isNull()) {
        std::cout << "文件为空，使用示例数据。" << std::endl;
        file.close();
        return createSampleQuestions();
    }

    std::cout << "文件头: " << header.toStdString() << std::endl;

    int lineNum = 1;
    int successCount = 0;

    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        lineNum++;

        if (line.isEmpty()) continue;

        // 简化的CSV解析 - 使用Qt内置的CSV解析
        QStringList parts;
        QString currentField;
        bool inQuotes = false;

        for (int i = 0; i < line.length(); ++i) {
            QChar ch = line[i];

            if (ch == '"') {
                inQuotes = !inQuotes;
            } else if (ch == ',' && !inQuotes) {
                parts.append(currentField.trimmed());
                currentField.clear();
            } else {
                currentField.append(ch);
            }
        }
        parts.append(currentField.trimmed());

        // 移除字段中的引号
        for (int i = 0; i < parts.size(); ++i) {
            parts[i] = parts[i].replace("\"", "");
        }

        // 验证数据完整性
        if (parts.size() < 3) {
            std::cout << "警告: 第 " << lineNum << " 行数据不完整，只有 " << parts.size() << " 列，跳过。" << std::endl;
            std::cout << "行内容: " << line.toStdString() << std::endl;
            continue;
        }

        // 检查ID
        bool ok;
        int id = parts[0].toInt(&ok);
        if (!ok || id <= 0) {
            std::cout << "警告: 第 " << lineNum << " 行ID无效: " << parts[0].toStdString() << "，跳过。" << std::endl;
            continue;
        }

        // 检查问题文本
        QString text = parts[2];
        if (text.isEmpty()) {
            std::cout << "警告: 第 " << lineNum << " 行问题文本为空，跳过。" << std::endl;
            continue;
        }

        // 创建问题对象
        Question q;
        q.id = id;
        q.category = parts[1].toStdString();
        q.text = text.toStdString();
        q.score = 0;

        questions.push_back(q);
        successCount++;

        std::cout << "成功读取问题 " << id << ": " << text.toStdString() << std::endl;
    }

    file.close();

    if (questions.empty()) {
        std::cout << "未成功读取任何问题，使用示例数据。" << std::endl;
        return createSampleQuestions();
    }

    std::cout << "成功读取 " << successCount << " 个问题。" << std::endl;
    return questions;
}








// 显示问题并获取用户评分
void PDPtest::conductSurvey(vector<Question>& questions) {
    std::cout << "\n开始进行调查..." << std::endl;
    std::cout << "共有 " << questions.size() << " 个问题需要回答。" << std::endl;
    std::cout << "=================================" << std::endl;
    for (auto& question : questions) {
        std::cout << "问题 " << question.id << ": " << question.text << std::endl;

        QString prompt = QString::fromStdString("问题 " + to_string(question.id) + " 评分");
        int score = getInputFromDialog(prompt, 1, 5);
        question.score = score;

        std::cout << "已记录评分: " << score << std::endl;
        std::cout << "---------------------------------" << std::endl;
    }

    std::cout << "调查完成！" << std::endl;
}

// 按类别统计分数
vector<CategoryResult> PDPtest::calculateCategoryScores(const vector<Question>& questions) {
    map<string, CategoryResult> categoryMap;

    for (const auto& question : questions) {
        if (categoryMap.find(question.category) == categoryMap.end()) {
            CategoryResult result;
            result.name = question.category;
            result.totalScore = 0;
            categoryMap[question.category] = result;
        }

        categoryMap[question.category].totalScore += question.score;
        categoryMap[question.category].questionIds.push_back(question.id);
    }

    vector<CategoryResult> results;
    for (const auto& pair : categoryMap) {
        results.push_back(pair.second);
    }

    return results;
}

// 输入分数数组，得到统计结果
AnalysisResult PDPtest::analyzeScores(const vector<CategoryResult>& results) {
    AnalysisResult analysis;
    vector<int> scores;

    for (const auto& result : results) {
        scores.push_back(result.totalScore);
    }

    if (scores.empty()) {
        analysis.average = 0;
        analysis.maxScore = 0;
        analysis.minScore = 0;
        analysis.standardDeviation = 0;
        return analysis;
    }

    analysis.maxScore = *max_element(scores.begin(), scores.end());
    analysis.minScore = *min_element(scores.begin(), scores.end());
    analysis.average = 0.0;

    for (int i = 0; i < scores.size(); i++) {
        analysis.average += scores[i];
        if (scores[i] == analysis.maxScore) {
            analysis.maxIndices.push_back(i);
        }
        if (scores[i] == analysis.minScore) {
            analysis.minIndices.push_back(i);
        }
    }
    analysis.average /= scores.size();

    double variance = 0.0;
    for (int score : scores) {
        variance += pow(score - analysis.average, 2);
    }
    analysis.standardDeviation = sqrt(variance / scores.size());

    double thresholdHigh = analysis.average * 1.15;
    double thresholdLow = analysis.average * 0.85;

    analysis.hasDominantType = (analysis.maxIndices.size() == 1 && analysis.maxScore > thresholdHigh);
    analysis.hasTwoStrongTypes = false;

    int strongCount = 0;
    for (int score : scores) {
        if (score > thresholdHigh) {
            strongCount++;
        }
    }
    analysis.hasTwoStrongTypes = (strongCount == 2);

    analysis.hasWeakType = (analysis.minScore < thresholdLow);
    analysis.isBalanced = (analysis.standardDeviation < analysis.average * 0.07);

    return analysis;
}

// 展示统计结果
void PDPtest::displayPersonalityResults(const vector<CategoryResult>& results, const AnalysisResult& analysis) {
    std::cout << "\n=== 性格属性分析结果 ===" << std::endl;
    std::cout << "您的得分情况：" << std::endl;

    int maxScore = 0;
    string topCategory;

    for (const auto& item : results) {
        std::cout << "类别: " << item.name << std::endl;
        std::cout << "包含的问题序号: ";
        for (size_t i = 0; i < item.questionIds.size(); i++) {
            std::cout << item.questionIds[i];
            if (i < item.questionIds.size() - 1) {
                std::cout << ", ";
            }
        }
        std::cout << std::endl;
        std::cout << "总分: " << item.totalScore << std::endl;
        std::cout << "***************" << std::endl;

        if (item.totalScore > maxScore) {
            maxScore = item.totalScore;
            topCategory = item.name;
        }
    }

    std::cout << "最高分类别: " << topCategory << " (总分: " << maxScore << ")" << std::endl;
    std::cout << "\n统计分析：" << std::endl;
    std::cout << "平均分: " << analysis.average << std::endl;
    std::cout << "最高分: " << analysis.maxScore << std::endl;
    std::cout << "最低分: " << analysis.minScore << std::endl;
    std::cout << "分数差异度: " << analysis.standardDeviation << std::endl;
    std::cout << "-----------------------------" << std::endl;

    std::cout << "\n=== 性格判断 ===" << std::endl;

    if (analysis.isBalanced) {
        std::cout << "恭喜你！你是一个面面俱到、近似完美性格的人！" << std::endl;
        std::cout << "你的各项分数都比较接近，说明你在不同情境下都能灵活应对。" << std::endl;
    }
    else if (analysis.hasDominantType && !results.empty()) {
        std::cout << "你是典型的" << topCategory << "特质！" << std::endl;
        std::cout << "你的" << topCategory << "特质非常突出。" << std::endl;
    }
    else if (analysis.hasTwoStrongTypes && analysis.maxIndices.size() >= 2) {
        string type1 = results[analysis.maxIndices[0]].name;
        string type2 = results[analysis.maxIndices[1]].name;
        std::cout << "你是" << type1 << "和" << type2 << "的综合属性！" << std::endl;
        std::cout << "这两种特质的结合让你具有独特的优势。" << std::endl;
    }

    if (analysis.hasWeakType && !analysis.minIndices.empty() && !results.empty()) {
        string weakType = results[analysis.minIndices[0]].name;
        std::cout << "\n提升建议：" << std::endl;
        std::cout << "你的" << weakType << "属性相对较弱，可以考虑加强这方面的能力。" << std::endl;
    }
}

// 职业人格分析
void PDPtest::explain() {
    bool continueExplaining = true;

    while (continueExplaining) {
        QStringList items;
        items << "孔雀型" << "考拉型" << "老虎型" << "猫头鹰型" << "变色龙型" << "退出";

        bool ok;
        QString choice = QInputDialog::getItem(this, "职业人格解析",
                                               "请选择您想查看的职业人格解析:",
                                               items, 0, false, &ok);

        if (!ok || choice == "退出") {
            break;
        }

        std::cout << "\n=== " << choice.toStdString() << "解析 ===" << std::endl;

        if (choice == "孔雀型") {
            std::cout << "孔雀型(表达型)" << std::endl;
            std::cout<<"在任何团体内，都是人缘最好和最受欢迎的人，是最能吹起领导号角的人物。" <<std::endl;
            std::cout<<"你具有高度的表达能力和社交能力，口才流畅、热情幽默，擅于人际关系的建立:你天生具备乐观与和善的性格，\n有真诚的同情心和感染他人的能力，在以团队合作为主的工作环境中，会有最好的表现。"<< std::endl;
            std::cout<<"◎个性特点:很热心，够乐观，口才流畅，好交朋友风度翩翩,诚恳热心。热情洋溢、好交朋友、口才流畅个性乐观、表现欲强。" <<std::endl;
            std::cout<<"◎优点:你生性活泼，能够使人兴奋;你善于建立同盟或搞好关系来实现目标。" <<std::endl;
            std::cout<<"◎缺点:因其跳跃性的思考模式，常无法顾及细节以及对事情的完成执着度，防止情绪化。"<< std::endl;
            std::cout<<"◎最适合的工作:适合需要当众表现、引人注目态度公开的工作;适合人际导向类的工作;适合在推动新思维、执行某种新使命或推广某项宣传等任务的工作。"<< std::endl;
        }
        else if (choice == "考拉型") {
            std::cout<<"考拉型(耐心型)，"<<std::endl;
            std::cout<<"生活讲求律规但也随缘从容，面对困境，能泰然自若。你强调无为而治，能与周围的人和睦相处而不树敌，是公司和员工重建互信的不二人选;\n有能力为企业赚取长远利益，或为公司打好永续经营的基础。"<<std::endl;
            std::cout<<"◎个性特点:稳定、敦厚、规律、不好冲突。行事稳健、强调平实，有过人的耐力，温和善良。"<<std::endl;
            std::cout<<"◎优点:你对其他人的感情很敏感，这使你在集体环境中左右逢源。"<<std::endl;
            std::cout<<"◎缺点:你不喜欢面对与同事意见不和的局面，不愿处理争执，很难坚持自己的观点和迅速做出决定。"<<std::endl;
            std::cout<<"◎最适合的工作:你适宜安定内部的管理工作，是极佳的人事领导者;适合在需要专业精密技巧的领域或在气氛和谐的职场环境中。"<<std::endl;
        }
        else if (choice == "老虎型") {
            std::cout<<"老虎型(支配型)"<<std::endl;
            std::cout<<"具备高支配型特质，竞争力强、好胜心盛、积极自信,是个有决断力的组织者。"<<std::endl;
            std::cout<<"你胸怀大志、具有强烈的企图心;勇于冒险，行动力强，只要认定目标就勇往直前;喜欢掌握全局、发号施令，倾向以权威作风来进行决策。"<<std::endl;
            std::cout<<"◎个性特点: 有自信，够权威，决断力高，竞争性强胸怀大志，喜欢评估。企图心强烈，喜欢冒险，个性积极，竞争力强，有对抗性。"<<std::endl;
            std::cout<<"◎优点:善于控制局面并能果断地作出决定，往往成就非凡。"<<std::endl;
            std::cout<<"◎缺点:当感到压力时，你可能太重视迅速的完成工作，容易忽视细节，可能忽视自己和别人的情感。由于要求过高,加之好胜的天性,有时会成为工作狂。"<<std::endl;
            std::cout<<"◎最适合的工作:开创性与改革性的工作，在开拓市场的时代或需要执行改革的环境中，最容易有出色的表现。"<<std::endl;

        }
        else if (choice == "猫头鹰型") {
            std::cout<<"猫头鹰型(精确型)"<<std::endl;
            std::cout<<"你是个完美主义者，常会让人觉得“吹毛求疵”，但细节条理化、精确度高的特征，又成为最佳的品质保证者。\n你重规则轻情感，事事以规则为准绳，并以之为主导思想;\n性格内敛、善于以数字作为表达工具，而不大擅长以语言来沟通;\n你讲究制度化事事检查以求正确无误，甚至为了办事精确，不惜对人吹毛求疵，以显现自己一切照章办事的态度和求取完美的精神，不易维持团队内的团结和凝聚力。"<<std::endl;
            std::cout<<"◎个性特点:传统，注重细节，条理分明，责任感强重щ都打利视纪律。保守、分析力强，精准度高，喜欢把细节条例化，个性拘谨含蓄。"<<std::endl;
            std::cout<<"◎优点:天生就有爱找出事情真相的习性，耐心仔细考察所有的细节，并想出合乎逻辑的解决办法。"<<std::endl;
            std::cout<<"◎缺点:把事实和精确度置于感情之前，会被认为感情冷漠:在压力下，容易分析过度，钻进牛角尖，"<<std::endl;
            std::cout<<"◎最适合的工作:在架构稳定和制度健全的组织环境中工作;创造和创新能力相对较弱，因而不宜担任需要创建或创新能力的任务。"<<std::endl;

        }
        else if (choice == "变色龙型") {
            std::cout<<"变色龙型(整合型)"<<std::endl;
            std::cout<<"中庸不极端，凡是不执着，韧性极强，擅于沟通是天生的谈判家，游走折中的高手。\n你事事求中立并倾向站在没有立场的位置，故在冲突的环境中能够游刃有余;你是支配型、表达型、耐心型、精确型四种特质的综合体，具有高度的应变能力;\n处事圆融，弹性极强，处事处处留有余地，行事绝对不会走偏锋极端。"<<std::endl;
            std::cout<<"◎个性特点:没有突出个性，兼容并蓄，以中庸之道处世;性格善变，处事极具弹性，形变能力强。"<<std::endl;
            std::cout<<"◎优点:善于在工作中调整自己的角色去适应环境，具有很好的沟通能力。"<<std::endl;
            std::cout<<"◎缺点:从别人眼中看变色龙族群，会觉得你较无个性及原则。"<<std::endl;
            std::cout<<"◎最适合的工作:你能密切地融合于各种环境中适合进行企业对内对外的各种交涉，只要任务确实和目标清楚，都能恰如其分地完成其任务。"<<std::endl;
        }

        std::cout << "---------------------------------" << std::endl;
    }
}




// 个人天赋特质测试
void PDPtest::selftest() {
    std::string filename = "data/questions.csv";  // 改为相对路径

    std::cout << "\n=== 开始个人天赋特质调查 ===" << std::endl;
        std::cout << "当前工作目录: " << QDir::currentPath().toStdString() << std::endl;

    std::cout << "请标示出最足以描述您所认为的\"真正的我\"的答案" << std::endl;
    std::cout << "1分表示不符合，5分表示很符合" << std::endl;

    vector<Question> questions = readQuestionsFromCSV(filename);
    if (questions.empty()) {
        std::cout << "错误：没有读取到任何问题！" << std::endl;
        return;
    }

    std::cout << "成功读取 " << questions.size() << " 个问题。" << std::endl;
    conductSurvey(questions);

    vector<CategoryResult> results = calculateCategoryScores(questions);
    AnalysisResult analysis = analyzeScores(results);

    std::cout << "\n下面展示您的自我天赋特质" << std::endl;
    displayPersonalityResults(results, analysis);

    // 询问是否查看解析
    QMessageBox::StandardButton reply = QMessageBox::question(this, "查看解析",
                                                              "是否查看详细的职业人格解析？",
                                                              QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        explain();
    }
}

// 工作中的天赋特质测试
void PDPtest::worktest() {
    std::string filename = "data/questions2.csv";  // 改为相对路径

    std::cout << "\n=== 开始工作中的天赋特质调查 ===" << std::endl;
    std::cout << "当前工作目录: " << QDir::currentPath().toStdString() << std::endl;

    std::cout << "请标示出最足以描述您在过去三个月参与各项活动时的表现" << std::endl;
    std::cout << "1分表示不符合，5分表示很符合" << std::endl;

    vector<Question> questions = readQuestionsFromCSV(filename);
    if (questions.empty()) {
        std::cout << "错误：没有读取到任何问题！" << std::endl;
        return;
    }

    std::cout << "成功读取 " << questions.size() << " 个问题。" << std::endl;
    conductSurvey(questions);

    vector<CategoryResult> results = calculateCategoryScores(questions);
    AnalysisResult analysis = analyzeScores(results);

    std::cout << "\n下面展示您工作中的天赋特质" << std::endl;
    displayPersonalityResults(results, analysis);

    QMessageBox::StandardButton reply = QMessageBox::question(this, "查看解析",
                                                              "是否查看详细的职业人格解析？",
                                                              QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        explain();
    }
}

// 按钮点击事件
void PDPtest::on_selfTestButton_clicked() {
    ui->textOutput->clear();
    selftest();
}

void PDPtest::on_workTestButton_clicked() {
    ui->textOutput->clear();
    worktest();
}

void PDPtest::on_clearButton_clicked() {
    ui->textOutput->clear();
    std::cout << "输出已清空" << std::endl;
}

void PDPtest::on_exitButton_clicked() {
    std::cout << "感谢使用PDP性格测试系统！" << std::endl;
    this->close();
}

void PDPtest::on_commandLinkButton_clicked()
{
    emit backToMainRequested();
}

