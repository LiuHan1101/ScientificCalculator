#include "calculateplus.h"
#include "ui_calculateplus.h"
#include <QDebug>
#include <QTimer>
#include <QKeyEvent>
#include <QRegularExpression>

CalculatePlus::CalculatePlus(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::CalculatePlus)
{
    ui->setupUi(this);

    // 初始化计算器状态
    resetCalculator();

    // 设置样式
    setCalculatorStyle();
}

CalculatePlus::~CalculatePlus()
{
    delete ui;
}

void CalculatePlus::resetCalculator()
{
    currentValue = 0.0;
    storedValue = 0.0;
    lastOperator = '\0';
    waitingForOperand = true;
    currentInput = "";

    updateDisplay();
}

void CalculatePlus::updateDisplay()
{
    if (currentInput.isEmpty()) {
        // 使用 QRegularExpression 替代 QRegExp
        QString displayText = QString::number(currentValue, 'f', 6);
        displayText.remove(QRegularExpression("\\.?0+$"));  // 移除尾随零
        ui->lcdNumber->display(displayText);
    } else {
        ui->lcdNumber->display(currentInput);
    }
}

void CalculatePlus::setCalculatorStyle()
{
    // 设置窗口样式
    this->setStyleSheet(
        "CalculatePlus {"
        "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #2C3E50, stop:1 #34495E);"
        "}"

        "QLCDNumber {"
        "   color: #ECF0F1;"
        "   background-color: #1C2833;"
        "   border: 2px solid #566573;"
        "   border-radius: 10px;"
        "   font-size: 24px;"
        "}"

        "QPushButton {"
        "   background-color: #566573;"
        "   color: #ECF0F1;"
        "   border: 2px solid #2C3E50;"
        "   border-radius: 8px;"
        "   font-size: 18px;"
        "   font-weight: bold;"
        "   min-width: 50px;"
        "   min-height: 50px;"
        "}"

        "QPushButton:hover {"
        "   background-color: #5D6D7E;"
        "   border: 2px solid #3498DB;"
        "}"

        "QPushButton:pressed {"
        "   background-color: #3498DB;"
        "}"
        );
}

void CalculatePlus::appendNumber(const QString &digit)
{
    if (waitingForOperand) {
        currentInput = digit;
        waitingForOperand = false;
    } else {
        // 防止输入过长的数字
        if (currentInput.length() < 15) {
            currentInput += digit;
        }
    }
    updateDisplay();
}

// 数字按钮处理
void CalculatePlus::on_pushButton_0_clicked() { appendNumber("0"); }
void CalculatePlus::on_pushButton_1_clicked() { appendNumber("1"); }
void CalculatePlus::on_pushButton_2_clicked() { appendNumber("2"); }
void CalculatePlus::on_pushButton_3_clicked() { appendNumber("3"); }
void CalculatePlus::on_pushButton_4_clicked() { appendNumber("4"); }
void CalculatePlus::on_pushButton_5_clicked() { appendNumber("5"); }
void CalculatePlus::on_pushButton_6_clicked() { appendNumber("6"); }
void CalculatePlus::on_pushButton_7_clicked() { appendNumber("7"); }
void CalculatePlus::on_pushButton_8_clicked() { appendNumber("8"); }
void CalculatePlus::on_pushButton_9_clicked() { appendNumber("9"); }

// 小数点按钮
void CalculatePlus::on_pushButton_dot_clicked()
{
    if (waitingForOperand) {
        currentInput = "0.";
        waitingForOperand = false;
    } else if (!currentInput.contains('.')) {
        currentInput += ".";
    }
    updateDisplay();
}

void CalculatePlus::handleOperator(char op)
{
    if (!waitingForOperand) {
        // 如果有当前输入，先计算
        if (!currentInput.isEmpty()) {
            currentValue = currentInput.toDouble();
        }

        // 如果有之前的运算符，先执行计算
        if (lastOperator != '\0') {
            performCalculation();
        } else {
            storedValue = currentValue;
        }

        currentInput = "";
    }

    lastOperator = op;
    waitingForOperand = true;

    // 显示当前状态
    ui->lcdNumber->display(QString("%1 %2").arg(storedValue).arg(op));
}

// 运算符按钮处理
void CalculatePlus::on_pushButton_plus_clicked()
{
    handleOperator('+');
}

void CalculatePlus::on_pushButton_minus_clicked()
{
    handleOperator('-');
}

void CalculatePlus::on_pushButton_multiply_clicked()
{
    handleOperator('*');
}

void CalculatePlus::on_pushButton_divide_clicked()
{
    handleOperator('/');
}

// 等号按钮
void CalculatePlus::on_pushButton_equal_clicked()
{
    if (!waitingForOperand && !currentInput.isEmpty()) {
        currentValue = currentInput.toDouble();
    }

    if (lastOperator != '\0') {
        performCalculation();
        lastOperator = '\0';
        waitingForOperand = true;
        currentInput = "";
    }
}

void CalculatePlus::performCalculation()
{
    double result = storedValue;
    bool validOperation = true;

    switch(lastOperator) {
    case '+':
        result += currentValue;
        break;
    case '-':
        result -= currentValue;
        break;
    case '*':
        result *= currentValue;
        break;
    case '/':
        if (currentValue != 0.0) {
            result /= currentValue;
        } else {
            // 除零错误处理
            ui->lcdNumber->display("Error");
            validOperation = false;
            QTimer::singleShot(2000, this, [this]() {
                resetCalculator();
            });
        }
        break;
    default:
        validOperation = false;
        break;
    }

    if (validOperation) {
        storedValue = result;
        currentValue = result;
        // 使用 QRegularExpression 格式化显示
        QString displayText = QString::number(result, 'f', 10);
        displayText.remove(QRegularExpression("0+$"));     // 移除尾随零
        displayText.remove(QRegularExpression("\\.$"));    // 移除单独的小数点
        ui->lcdNumber->display(displayText);
    }
}

// 清除按钮
void CalculatePlus::on_pushButton_clear_clicked()
{
    resetCalculator();
}

// 退格按钮
void CalculatePlus::on_pushButton_backspace_clicked()
{
    if (!waitingForOperand && !currentInput.isEmpty()) {
        currentInput.chop(1);
        if (currentInput.isEmpty() || currentInput == "-") {
            currentInput = "0";
            waitingForOperand = true;
        }
        updateDisplay();
    }
}

// 增强版连续计算功能
void CalculatePlus::calculateEnhanced()
{
    qDebug() << "增强版计算器已启动，支持连续运算";
}

// 返回按钮 - 发出返回主菜单信号
void CalculatePlus::on_pushButton_clicked()
{
    emit backToMainRequested();  // 发出返回主菜单的信号
    qDebug() << "CalculatePlus: 请求返回主菜单";
}
