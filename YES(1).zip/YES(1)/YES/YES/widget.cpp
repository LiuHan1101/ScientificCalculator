#include "widget.h"
#include "ui_widget.h"
#include "equation.h"
#include "fitnesstest.h"
#include "gpa.h"
#include "bmi_calculator.h"
#include "pdptest.h"
#include "calculateplus.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QRadioButton>
#include <QPushButton>
#include <QGroupBox>
#include <QButtonGroup>
#include <QStackedWidget>
#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
    , stackedWidget(nullptr)
    , mainMenuPage(nullptr)
    , arithmeticPage(nullptr)
    , bmiPage(nullptr)
    , pdpPage(nullptr)
    , equationPage(nullptr)
    , fitnessPage(nullptr)
    , gpaPage(nullptr)
{
    ui->setupUi(this);
    initializeUI();
}

Widget::~Widget()
{
    delete ui;
    qDebug() << "Widget destroyed";
}

void Widget::initializeUI()
{
    // 设置窗口属性
    setWindowProperties();

    // 创建主布局
    createMainLayout();

    // 创建所有功能页面
    createAllPages();

    // 默认显示主菜单
    stackedWidget->setCurrentWidget(mainMenuPage);

    qDebug() << "Widget初始化完成";
}

void Widget::setWindowProperties()
{
    this->setWindowTitle("科学计算器");
    this->setMinimumSize(700, 550);
    this->setStyleSheet("background-color: #f8f9fa;");
}

void Widget::createMainLayout()
{
    // 创建堆栈窗口
    stackedWidget = new QStackedWidget(this);

    // 主布局
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->addWidget(stackedWidget);
}

void Widget::createAllPages()
{
    createMainMenu();
    createArithmeticPage();
    createEquationPage();
    createGPAPage();
    createFitnessPage();
    createBMIPage();
    createPDPPage();
}

void Widget::createMainMenu()
{
    mainMenuPage = new QWidget();
    mainMenuPage->setStyleSheet("background-color: white;");

    QVBoxLayout *layout = new QVBoxLayout(mainMenuPage);
    layout->setContentsMargins(30, 30, 30, 30);
    layout->setSpacing(20);

    // 创建标题
    createTitleLabel(layout);

    // 创建模式选择区域
    createModeSelectionGroup(layout);

    // 添加到堆栈
    stackedWidget->addWidget(mainMenuPage);
}

void Widget::createTitleLabel(QVBoxLayout *layout)
{
    QLabel *titleLabel = new QLabel("科学计算器", mainMenuPage);
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setStyleSheet("font-size: 28px; font-weight: bold; color: #2c3e50; margin: 20px;");
    layout->addWidget(titleLabel);
}

void Widget::createModeSelectionGroup(QVBoxLayout *layout)
{
    QGroupBox *modeGroup = new QGroupBox("选择计算模式", mainMenuPage);
    modeGroup->setStyleSheet(getGroupBoxStyle());

    QVBoxLayout *modeLayout = new QVBoxLayout(modeGroup);
    modeLayout->setSpacing(12);

    // 创建并配置单选按钮
    createRadioButtons(modeLayout);

    layout->addWidget(modeGroup);
    layout->addStretch();
}

QString Widget::getGroupBoxStyle()
{
    return R"(
        QGroupBox {
            font-weight: bold;
            font-size: 16px;
            color: #34495e;
            border: 2px solid #dee2e6;
            border-radius: 10px;
            margin-top: 10px;
            padding-top: 15px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 15px;
            padding: 0 10px 0 10px;
        }
    )";
}

QString Widget::getRadioButtonStyle()
{
    return R"(
        QRadioButton {
            font-size: 14px;
            padding: 10px;
            color: #555555;
        }
        QRadioButton::indicator {
            width: 18px;
            height: 18px;
        }
        QRadioButton::indicator:checked {
            background-color: #4dabf7;
            border: 2px solid #4dabf7;
        }
    )";
}

void Widget::createRadioButtons(QVBoxLayout *modeLayout)
{
    // 创建单选按钮数组
    QRadioButton *radioButtons[] = {
        new QRadioButton("四则运算", mainMenuPage),
        new QRadioButton("解方程", mainMenuPage),
        new QRadioButton("绩点计算", mainMenuPage),
        new QRadioButton("体测成绩计算", mainMenuPage),
        new QRadioButton("BMI计算", mainMenuPage),
        new QRadioButton("PDP测试", mainMenuPage)
    };

    // 配置样式并添加到布局
    QString radioStyle = getRadioButtonStyle();
    for (QRadioButton *radioBtn : radioButtons) {
        radioBtn->setStyleSheet(radioStyle);
        modeLayout->addWidget(radioBtn);
    }

    // 连接信号槽
    connectRadioButtons(radioButtons);
}

void Widget::connectRadioButtons(QRadioButton *radioButtons[])
{
    connect(radioButtons[0], &QRadioButton::clicked, this, &Widget::onArithmeticClicked);
    connect(radioButtons[1], &QRadioButton::clicked, this, &Widget::onEquationClicked);
    connect(radioButtons[2], &QRadioButton::clicked, this, &Widget::onGPAClicked);
    connect(radioButtons[3], &QRadioButton::clicked, this, &Widget::onFitnessClicked);
    connect(radioButtons[4], &QRadioButton::clicked, this, &Widget::onBMIClicked);
    connect(radioButtons[5], &QRadioButton::clicked, this, &Widget::onPDPClicked);
}

void Widget::createArithmeticPage()
{
    arithmeticPage = new CalculatePlus();

    connect(arithmeticPage, &CalculatePlus::backToMainRequested,
            this, &Widget::switchToMainMenu);

    stackedWidget->addWidget(arithmeticPage);
    qDebug() << "四则运算页面创建完成（使用增强版Calculateplus）";
}

void Widget::createEquationPage()
{
    equationPage = new Equation();
    setupPageConnections(equationPage);
    stackedWidget->addWidget(equationPage);
    qDebug() << "Equation页面创建完成";
}

void Widget::createGPAPage()
{
    gpaPage = new Gpa();
    setupPageConnections(gpaPage);
    stackedWidget->addWidget(gpaPage);
    qDebug() << "绩点计算页面创建完成";
}

void Widget::createFitnessPage()
{
    fitnessPage = new Fitnesstest();
    setupPageConnections(fitnessPage);
    stackedWidget->addWidget(fitnessPage);
    qDebug() << "体测成绩计算页面创建完成";
}

void Widget::createBMIPage()
{
    bmiPage = new BMI_Calculator();
    setupPageConnections(bmiPage);
    stackedWidget->addWidget(bmiPage);
    qDebug() << "BMI计算页面创建完成";
}

void Widget::createPDPPage()
{
    pdpPage = new PDPtest();

    // 使用新式语法连接信号槽
    connect(pdpPage, &PDPtest::backToMainRequested, this, &Widget::switchToMainMenu);

    stackedWidget->addWidget(pdpPage);
    qDebug() << "PDP测试页面创建完成";
}

void Widget::setupPageConnections(QWidget *page)
{
    if (auto *equationPage = qobject_cast<Equation*>(page)) {
        connect(equationPage, &Equation::backToMainRequested, this, &Widget::switchToMainMenu);
    } else if (auto *gpaPage = qobject_cast<Gpa*>(page)) {
        connect(gpaPage, &Gpa::backToMainRequested, this, &Widget::switchToMainMenu);
    } else if (auto *fitnessPage = qobject_cast<Fitnesstest*>(page)) {
        connect(fitnessPage, &Fitnesstest::backToMainRequested, this, &Widget::switchToMainMenu);
    } else if (auto *bmiPage = qobject_cast<BMI_Calculator*>(page)) {
        connect(bmiPage, &BMI_Calculator::backToMainRequested, this, &Widget::switchToMainMenu);
    }

}

// 页面切换槽函数
void Widget::onArithmeticClicked()
{
    switchToPage(arithmeticPage, "四则运算");
}

void Widget::onEquationClicked()
{
    switchToPage(equationPage, "解方程");
}

void Widget::onGPAClicked()
{
    switchToPage(gpaPage, "绩点计算");
}

void Widget::onFitnessClicked()
{
    switchToPage(fitnessPage, "体测成绩计算");
}

void Widget::onBMIClicked()
{
    if (bmiPage) {
        bmiPage->resetCalculator();
    }
    switchToPage(bmiPage, "BMI计算");
}

void Widget::onPDPClicked()
{
    switchToPage(pdpPage, "PDP测试");
}

void Widget::switchToPage(QWidget *page, const QString &pageName)
{
    if (page && stackedWidget) {
        stackedWidget->setCurrentWidget(page);
        qDebug() << "切换到" << pageName << "页面";
    } else {
        qDebug() << "错误：" << pageName << "页面未初始化";
    }
}

void Widget::switchToMainMenu()
{
    if (!stackedWidget || !mainMenuPage) {
        qDebug() << "错误：主菜单页面未初始化";
        return;
    }

    // 重置BMI计算器状态
    if (bmiPage) {
        bmiPage->resetCalculator();
    }

    // 切换到主菜单
    stackedWidget->setCurrentWidget(mainMenuPage);
    qDebug() << "返回主菜单";
}
