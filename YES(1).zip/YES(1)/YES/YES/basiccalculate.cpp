#include "basiccalculate.h"
#include "ui_basiccalculate.h"
#include <QDebug>
#include <QTimer>
#include <QKeyEvent>
#include <QRegularExpression>
#include "Widget.h"

BasicCalculate::BasicCalculate(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::BasicCalculate)
{
    ui->setupUi(this);

    // 初始化计算器状态
    resetCalculator();

    // 设置样式
    setCalculatorStyle();
}

BasicCalculate::~BasicCalculate()
{
    delete ui;
}

void BasicCalculate::resetCalculator()
{
    currentValue = 0.0;
    storedValue = 0.0;
    lastOperator = '\0';
    waitingForOperand = true;
    currentInput = "";
    calculationPerformed = false;

    updateDisplay();
}

void BasicCalculate::updateDisplay()
{
    if (currentInput.isEmpty()) {
        QString displayText = QString::number(currentValue, 'f', 6);
        displayText.remove(QRegularExpression("\\.?0+$"));
        ui->lcdNumber->display(displayText);
    } else {
        ui->lcdNumber->display(currentInput);
    }
}

void BasicCalculate::setCalculatorStyle()
{
    // 设置窗口样式
    this->setStyleSheet(
        "BasicCalculate {"
        "   background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #2C3E50, stop:1 #34495E);"
        "}"

        "QLCDNumber {"
        "   color: #ECF0F1;"
        "   background-color: #1C2833;"
        "   border: 2px solid #566573;"
        "   border-radius: 10px;"
        "   font-size: 24px;"
        "}"

        "QPushButton {"
        "   background-color: #566573;"
        "   color: #ECF0F1;"
        "   border: 2px solid #2C3E50;"
        "   border-radius: 8px;"
        "   font-size: 18px;"
        "   font-weight: bold;"
        "   min-width: 50px;"
        "   min-height: 50px;"
        "}"

        "QPushButton:hover {"
        "   background-color: #5D6D7E;"
        "   border: 2px solid #3498DB;"
        "}"

        "QPushButton:pressed {"
        "   background-color: #3498DB;"
        "}"
        );
}

void BasicCalculate::appendNumber(const QString &digit)
{
    // 如果已经执行过一次计算，按数字键时重置计算器
    if (calculationPerformed) {
        resetCalculator();
    }

    if (waitingForOperand) {
        currentInput = digit;
        waitingForOperand = false;
    } else {
        if (currentInput.length() < 15) {
            currentInput += digit;
        }
    }
    updateDisplay();
}

// 数字按钮处理
void BasicCalculate::on_pushButton_0_clicked() { appendNumber("0"); }
void BasicCalculate::on_pushButton_1_clicked() { appendNumber("1"); }
void BasicCalculate::on_pushButton_2_clicked() { appendNumber("2"); }
void BasicCalculate::on_pushButton_3_clicked() { appendNumber("3"); }
void BasicCalculate::on_pushButton_4_clicked() { appendNumber("4"); }
void BasicCalculate::on_pushButton_5_clicked() { appendNumber("5"); }
void BasicCalculate::on_pushButton_6_clicked() { appendNumber("6"); }
void BasicCalculate::on_pushButton_7_clicked() { appendNumber("7"); }
void BasicCalculate::on_pushButton_8_clicked() { appendNumber("8"); }
void BasicCalculate::on_pushButton_9_clicked() { appendNumber("9"); }

// 小数点按钮
void BasicCalculate::on_pushButton_dot_clicked()
{
    // 如果已经执行过一次计算，按小数点键时重置计算器
    if (calculationPerformed) {
        resetCalculator();
    }

    if (waitingForOperand) {
        currentInput = "0.";
        waitingForOperand = false;
    } else if (!currentInput.contains('.')) {
        currentInput += ".";
    }
    updateDisplay();
}

void BasicCalculate::handleOperator(char op)
{
    // 如果已经执行过一次计算，不允许继续运算
    if (calculationPerformed) {
        return;
    }

    if (!waitingForOperand) {
        if (!currentInput.isEmpty()) {
            currentValue = currentInput.toDouble();
        }

        if (lastOperator != '\0') {
            performCalculation();
        } else {
            storedValue = currentValue;
        }

        currentInput = "";
    }

    lastOperator = op;
    waitingForOperand = true;

    // 显示当前状态
    ui->lcdNumber->display(QString("%1 %2").arg(storedValue).arg(op));
}

// 运算符按钮处理
void BasicCalculate::on_pushButton_plus_clicked()
{
    handleOperator('+');
}

void BasicCalculate::on_pushButton_minus_clicked()
{
    handleOperator('-');
}

void BasicCalculate::on_pushButton_multiply_clicked()
{
    handleOperator('*');
}

void BasicCalculate::on_pushButton_divide_clicked()
{
    handleOperator('/');
}

// 等号按钮
void BasicCalculate::on_pushButton_equal_clicked()
{
    // 如果已经执行过一次计算，按等号键时重置计算器
    if (calculationPerformed) {
        resetCalculator();
        return;
    }

    if (!waitingForOperand && !currentInput.isEmpty()) {
        currentValue = currentInput.toDouble();
    }

    if (lastOperator != '\0') {
        performCalculation();
        lastOperator = '\0';
        waitingForOperand = true;
        currentInput = "";
        calculationPerformed = true;
    }
}

void BasicCalculate::performCalculation()
{
    double result = storedValue;
    bool validOperation = true;

    switch(lastOperator) {
    case '+':
        result += currentValue;
        break;
    case '-':
        result -= currentValue;
        break;
    case '*':
        result *= currentValue;
        break;
    case '/':
        if (currentValue != 0.0) {
            result /= currentValue;
        } else {
            ui->lcdNumber->display("Error");
            validOperation = false;
            QTimer::singleShot(2000, this, [this]() {
                resetCalculator();
            });
        }
        break;
    default:
        validOperation = false;
        break;
    }

    if (validOperation) {
        storedValue = result;
        currentValue = result;
        QString displayText = QString::number(result, 'f', 10);
        displayText.remove(QRegularExpression("0+$"));
        displayText.remove(QRegularExpression("\\.$"));
        ui->lcdNumber->display(displayText);
    }
}

// 清除按钮
void BasicCalculate::on_pushButton_clear_clicked()
{
    resetCalculator();
}

// 退格按钮
void BasicCalculate::on_pushButton_backspace_clicked()
{
    // 如果已经执行过一次计算，按退格键时重置计算器
    if (calculationPerformed) {
        resetCalculator();
        return;
    }

    if (!waitingForOperand && !currentInput.isEmpty()) {
        currentInput.chop(1);
        if (currentInput.isEmpty() || currentInput == "-") {
            currentInput = "0";
            waitingForOperand = true;
        }
        updateDisplay();
    }
}

// 增强版计算功能（单次计算模式）
void BasicCalculate::calculateEnhanced()
{
    qDebug() << "单次计算器模式：每次计算完成后需要按清除键或数字键重新开始";
}

void BasicCalculate::on_pushButton_clicked()
{
    emit backToCalculateRequested();
}
