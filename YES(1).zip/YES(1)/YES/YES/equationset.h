#ifndef EQUATIONSET_H
#define EQUATIONSET_H

#include <QWidget>

namespace Ui {
class Equationset;
}

class Equationset : public QWidget
{
    Q_OBJECT

public:
    explicit Equationset(QWidget *parent = nullptr);
    ~Equationset();

signals:
    void returnToEquationRequested();
    void returnToMainRequested();

private slots:
    void on_solve_clicked();                    // 求解按钮
    void on_clear_clicked();                    // 清空按钮
    void on_returnToEquationButton_clicked();   // 返回方程选择
    void on_returnToMainButton_clicked();       // 返回主菜单

private:
    Ui::Equationset *ui;


};

#endif // EQUATIONSET_H
