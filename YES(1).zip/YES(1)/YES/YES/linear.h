#ifndef LINEAR_H
#define LINEAR_H

#include <QWidget>

namespace Ui {
class Linear;
}

class Linear : public QWidget
{
    Q_OBJECT

public:
    explicit Linear(QWidget *parent = nullptr);
    ~Linear();

signals:
    void returnToEquationRequested();
    void returnToMainRequested();

private slots:
    void on_pushButton_clicked();  // 求解按钮
    void on_pushButton_2_clicked(); // 清空按钮
    void on_returnToEquationButton_clicked(); // 返回方程选择按钮
    void on_returnToMainButton_clicked(); // 返回主菜单按钮

private:
    Ui::Linear *ui;

    QString decimalToFraction(double value, double tolerance = 1.0e-6);

};

#endif // LINEAR_H
