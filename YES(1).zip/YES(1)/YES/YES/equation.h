#ifndef EQUATION_H
#define EQUATION_H

#include <QWidget>

namespace Ui {
class equation;
}

class Linear;
class Quadratic;
class Equationset;

class Equation : public QWidget
{
    Q_OBJECT

public:
    explicit Equation(QWidget *parent = nullptr);
    ~Equation();

signals:
    void backToMainRequested();  // 确保这个信号存在

private slots:
    void on_radioButton_clicked();
    void on_radioButton_2_clicked();
    void on_radioButton_3_clicked();
    void on_returnToMainButton_clicked();

private:
    Ui::equation *ui;

    Linear *linearPage;
    Quadratic *quadraticPage;
    Equationset *binaryPage;

    void showEquationPage(QWidget *page);
    void hideAllPages();
};

#endif // EQUATION_H
