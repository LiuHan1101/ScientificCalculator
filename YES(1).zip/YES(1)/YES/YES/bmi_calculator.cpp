#include "bmi_calculator.h"
#include "ui_bmi_calculator.h"
#include "widget.h"
#include <QApplication>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QGroupBox>
#include <QMessageBox>
#include <QRegularExpressionValidator>
#include <QRadioButton>
#include <QButtonGroup>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QStackedWidget>

BMI_Calculator::BMI_Calculator(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::BMI_Calculator)
    , currentHeight(0)
    , currentWeight(0)
    , currentBMI(0)
{

   ui->setupUi(this);

    setupUI();
}

BMI_Calculator::~BMI_Calculator()
{
    delete ui;
}

void BMI_Calculator::setupUI()
{
    setWindowTitle("BMI计算器 - 莫兰迪风格");
    setFixedSize(480, 420);

    // 应用莫兰迪样式表
    setStyleSheet(getMorandiStyleSheet());

    // 主布局
    mainLayout = new QVBoxLayout(this);



    // 创建堆叠窗口
    stackedWidget = new QStackedWidget(this);

    // === 第一页：BMI计算 ===
    bmiPage = new QWidget();
    setupBmiPage();  // 修正函数名


    // === 第二页：是否查看体重调整 ===
    queryPage = new QWidget();
    setupQueryPage();  // 修正函数名


    // === 第三页：体重调整计算 ===
    weightAdjustmentPage = new QWidget();
    setupWeightAdjustmentPage();  // 修正函数名


    // === 第四页：正常体重范围查询 ===
    normalWeightPage = new QWidget();
    setupNormalWeightPage();  // 修正函数名


    // 将所有页面添加到堆叠窗口
    stackedWidget->addWidget(bmiPage);
    stackedWidget->addWidget(queryPage);
    stackedWidget->addWidget(weightAdjustmentPage);
    stackedWidget->addWidget(normalWeightPage);

    stackedWidget->setCurrentWidget(bmiPage);
    // 添加到主布局 - 修正错误的函数名

    mainLayout->addWidget(stackedWidget);
}


QString BMI_Calculator::getMorandiStyleSheet()
{
    return R"(
/* 完整的莫兰迪样式表内容 */
QWidget {
    background-color: #F8F7F4;
    font-family: "Microsoft YaHei", "Segoe UI";
    color: #5A5A5A;
}

QPushButton {
    background-color: #8FA3B3;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    color: white;
    font-size: 12px;
    font-weight: 500;
}

QPushButton:hover {
    background-color: #78909C;
}

QPushButton:pressed {
    background-color: #6C7D8C;
}

QLineEdit {
    background-color: white;
    border: 1px solid #E8D8C5;
    border-radius: 4px;
    padding: 6px 10px;
    font-size: 12px;
}

QLineEdit:focus {
    border: 1px solid #8FA3B3;
    background-color: #F8FBFF;
}

QLabel {
    background-color: transparent;
    color: #5A5A5A;
    font-size: 12px;
}

QGroupBox {
    font-weight: bold;
    border: 1px solid #E8D8C5;
    border-radius: 8px;
    margin-top: 10px;
    padding-top: 15px;
    background-color: white;
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top center;
    padding: 2px 8px;
    background-color: #E8D8C5;
    color: #5A5A5A;
    border-radius: 4px;
}
)";
}



void BMI_Calculator::setupBmiPage()  // 修正函数名
{
    QVBoxLayout *bmiLayout = new QVBoxLayout(bmiPage);

    QGroupBox *inputGroup = new QGroupBox("请输入您的身高和体重");
    QFormLayout *formLayout = new QFormLayout(inputGroup);

    QRegularExpressionValidator *validator = new QRegularExpressionValidator(QRegularExpression("[0-9]*\\.?[0-9]+"), this);

    heightEdit = new QLineEdit();
    heightEdit->setPlaceholderText("单位：厘米");
    heightEdit->setValidator(validator);
    formLayout->addRow("身高 (cm):", heightEdit);

    weightEdit = new QLineEdit();
    weightEdit->setPlaceholderText("单位：公斤");
    weightEdit->setValidator(validator);
    formLayout->addRow("体重 (kg):", weightEdit);

    calculateButton = new QPushButton("计算BMI");
    connect(calculateButton, &QPushButton::clicked, this, &BMI_Calculator::calculateBMI);

    bmiResultLabel = new QLabel("BMI结果将显示在这里");
    bmiCategoryLabel = new QLabel("");

    bmiLayout->addWidget(inputGroup);
    bmiLayout->addWidget(calculateButton);
    bmiLayout->addWidget(bmiResultLabel);
    bmiLayout->addWidget(bmiCategoryLabel);
    bmiLayout->addStretch();
}

void BMI_Calculator::setupQueryPage()  // 修正函数名
{
    QVBoxLayout *queryLayout = new QVBoxLayout(queryPage);

    queryLabel = new QLabel("您的体重不在正常范围内，是否要查看需要调整的体重？");
    queryLabel->setWordWrap(true);

    QButtonGroup *buttonGroup = new QButtonGroup(this);
    yesRadio = new QRadioButton("是，查看需要调整的体重");
    noRadio = new QRadioButton("否，查看正常体重范围");
    buttonGroup->addButton(yesRadio);
    buttonGroup->addButton(noRadio);


    queryConfirmButton = new QPushButton("确认");
    connect(queryConfirmButton, &QPushButton::clicked, this, &BMI_Calculator::onNormalWeightQueryChanged);

    queryLayout->addWidget(queryLabel);
    queryLayout->addWidget(yesRadio);
    queryLayout->addWidget(noRadio);
    queryLayout->addWidget(queryConfirmButton);
    queryLayout->addStretch();
}

void BMI_Calculator::setupWeightAdjustmentPage()  // 修正函数名
{
    QVBoxLayout *adjustmentLayout = new QVBoxLayout(weightAdjustmentPage);

    adjustmentLabel = new QLabel();
    adjustmentLabel->setWordWrap(true);

    adjustmentBackButton = new QPushButton("上一步");
    adjustmentNextButton = new QPushButton("查看正常体重范围");

    connect(adjustmentBackButton, &QPushButton::clicked, this, [this]() {
        stackedWidget->setCurrentWidget(queryPage);
    });
    connect(adjustmentNextButton, &QPushButton::clicked, this, &BMI_Calculator::showNormalWeightRangePage);

    adjustmentLayout->addWidget(adjustmentLabel);
    adjustmentLayout->addWidget(adjustmentBackButton);
    adjustmentLayout->addWidget(adjustmentNextButton);
    adjustmentLayout->addStretch();
}

void BMI_Calculator::setupNormalWeightPage()  // 修正函数名
{
    QVBoxLayout *normalLayout = new QVBoxLayout(normalWeightPage);

    QGroupBox *normalGroup = new QGroupBox("查询正常体重范围");
    QFormLayout *normalFormLayout = new QFormLayout(normalGroup);

    QRegularExpressionValidator *validator = new QRegularExpressionValidator(QRegularExpression("[0-9]*\\.?[0-9]+"), this);
    normalHeightEdit = new QLineEdit();
    normalHeightEdit->setPlaceholderText("单位：厘米");
    normalHeightEdit->setValidator(validator);
    normalFormLayout->addRow("请输入身高 (cm):", normalHeightEdit);

    normalWeightCalculateButton = new QPushButton("计算正常体重范围");
    connect(normalWeightCalculateButton, &QPushButton::clicked, this, &BMI_Calculator::calculateNormalWeightRange);

    normalWeightResultLabel = new QLabel("正常体重范围将显示在这里");
    normalWeightResultLabel->setWordWrap(true);

    finishButton = new QPushButton("完成");
    connect(finishButton, &QPushButton::clicked, this, &BMI_Calculator::resetCalculator);

    normalLayout->addWidget(normalGroup);
    normalLayout->addWidget(normalWeightCalculateButton);
    normalLayout->addWidget(normalWeightResultLabel);
    normalLayout->addWidget(finishButton);
    normalLayout->addStretch();
}



void BMI_Calculator::calculateBMI()
{
    QString heightText = heightEdit->text();
    QString weightText = weightEdit->text();

    if (heightText.isEmpty() || weightText.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请输入身高和体重！");
        return;
    }

    currentHeight = heightText.toDouble();
    currentWeight = weightText.toDouble();

    if (currentHeight <= 0 || currentWeight <= 0) {
        QMessageBox::warning(this, "输入错误", "身高和体重必须大于0！");
        return;
    }

    double heightInMeters = currentHeight / 100.0;
    currentBMI = currentWeight / (heightInMeters * heightInMeters);

    if (currentBMI < 18.5) {
        currentCategory = "偏瘦";
    } else if (currentBMI < 24) {
        currentCategory = "正常";
    } else if (currentBMI < 28) {
        currentCategory = "超重";
    } else {
        currentCategory = "肥胖";
    }

    bmiResultLabel->setText(QString("您的BMI: %1").arg(currentBMI, 0, 'f', 2));
    bmiCategoryLabel->setText(QString("体重状况: %1").arg(currentCategory));

    if (currentCategory != "正常") {
        showResultPage();
    } else {
        QMessageBox::information(this, "结果", "您的体重在正常范围内！");
    }
}

void BMI_Calculator::showResultPage()
{
    stackedWidget->setCurrentWidget(queryPage);
}

void BMI_Calculator::onNormalWeightQueryChanged()
{
    if (yesRadio->isChecked()) {
        calculateWeightToNormal();
    } else if (noRadio->isChecked()) {
        showNormalWeightRangePage();
    } else {
        QMessageBox::warning(this, "选择错误", "请选择一个选项！");
    }
}

void BMI_Calculator::calculateWeightToNormal()
{
    double heightInMeters = currentHeight / 100.0;
    double minNormalWeight = 18.5 * heightInMeters * heightInMeters;
    double maxNormalWeight = 24 * heightInMeters * heightInMeters;

    QString adjustmentText;
    if (currentCategory == "偏瘦") {
        double gainMin = minNormalWeight - currentWeight;
        double gainMax = maxNormalWeight - currentWeight;
        adjustmentText = QString("您需要增重 %1 到 %2 公斤才能达到正常体重范围。")
                             .arg(gainMin, 0, 'f', 1).arg(gainMax, 0, 'f', 1);
    } else {
        double loseMin = currentWeight - maxNormalWeight;
        double loseMax = currentWeight - minNormalWeight;
        adjustmentText = QString("您需要减重 %1 到 %2 公斤才能达到正常体重范围。")
                             .arg(loseMin, 0, 'f', 1).arg(loseMax, 0, 'f', 1);
    }

    adjustmentLabel->setText(adjustmentText);
    stackedWidget->setCurrentWidget(weightAdjustmentPage);
}

void BMI_Calculator::showWeightAdjustmentPage()
{
    stackedWidget->setCurrentWidget(weightAdjustmentPage);
}

void BMI_Calculator::showNormalWeightRangePage()
{
    normalHeightEdit->setText(QString::number(currentHeight));
    calculateNormalWeightRange();
}

void BMI_Calculator::calculateNormalWeightRange()
{
    QString heightText;
    if (stackedWidget->currentWidget() == normalWeightPage) {
        heightText = normalHeightEdit->text();
    } else {
        heightText = QString::number(currentHeight);
    }

    if (heightText.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请输入身高！");
        return;
    }

    double height = heightText.toDouble();
    if (height <= 0) {
        QMessageBox::warning(this, "输入错误", "身高必须大于0！");
        return;
    }

    double heightInMeters = height / 100.0;
    double minNormalWeight = 18.5 * heightInMeters * heightInMeters;
    double maxNormalWeight = 24 * heightInMeters * heightInMeters;

    QString resultText = QString("身高 %1 cm 的正常体重范围为: %2 - %3 公斤")
                             .arg(height).arg(minNormalWeight, 0, 'f', 1).arg(maxNormalWeight, 0, 'f', 1);

    normalWeightResultLabel->setText(resultText);
    stackedWidget->setCurrentWidget(normalWeightPage);
}

void BMI_Calculator::resetCalculator()
{
    heightEdit->clear();
    weightEdit->clear();
    normalHeightEdit->clear();
    bmiResultLabel->setText("BMI结果将显示在这里");
    bmiCategoryLabel->setText("");
    normalWeightResultLabel->setText("正常体重范围将显示在这里");
    stackedWidget->setCurrentWidget(bmiPage);

    // 重置单选按钮状态
    yesRadio->setAutoExclusive(false);
    noRadio->setAutoExclusive(false);
    yesRadio->setChecked(false);
    noRadio->setChecked(false);
    yesRadio->setAutoExclusive(true);
    noRadio->setAutoExclusive(true);

    // 确保回到第一页
    stackedWidget->setCurrentWidget(bmiPage);
}

int runbmi(int argc, char *argv[])
{
    QApplication app(argc, argv);
    BMI_Calculator calculator;
    calculator.show();
    return app.exec();
}

void BMI_Calculator::on_commandLinkButton_clicked()
{
    emit backToMainRequested();
}
