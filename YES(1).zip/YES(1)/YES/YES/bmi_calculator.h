#ifndef BMI_CALCULATOR_H
#define BMI_CALCULATOR_H

#include "qboxlayout.h"
#include "qlabel.h"
#include "qlineedit.h"
#include "qpushbutton.h"
#include "qradiobutton.h"
#include "qstackedwidget.h"
#include <QWidget>

#include "ui_bmi_calculator.h"
#include "widget.h"
#include <QApplication>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QGroupBox>
#include <QMessageBox>
#include <QRegularExpressionValidator>
#include <QRadioButton>
#include <QButtonGroup>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QStackedWidget>

namespace Ui {
class BMI_Calculator;
}

class BMI_Calculator : public QWidget
{
    Q_OBJECT

signals:
        void backToMainRequested();

public:
    explicit BMI_Calculator(QWidget *parent = nullptr);
    ~BMI_Calculator();
    void resetCalculator();

private slots:
    void calculateBMI();
    void onNormalWeightQueryChanged();
    void calculateWeightToNormal();
    void calculateNormalWeightRange();
    void on_commandLinkButton_clicked();

private:
    void setupUI();
    void showResultPage();
    void showWeightAdjustmentPage();
    void showNormalWeightRangePage();
    void addReturnButtonToPage(QWidget *page);  // 添加缺失的声明
    void setupBmiPage() ;
    void setupQueryPage();
    void setupWeightAdjustmentPage();
    void setupNormalWeightPage();
    QString getMorandiStyleSheet();


   Ui::BMI_Calculator *ui;

    // 页面控件
    QWidget *bmiPage;
    QWidget *queryPage;
    QWidget *weightAdjustmentPage;
    QWidget *normalWeightPage;

    // 输入控件
    QLineEdit *heightEdit;
    QLineEdit *weightEdit;
    QLineEdit *normalHeightEdit;

    // 标签控件
    QLabel *bmiResultLabel;
    QLabel *bmiCategoryLabel;
    QLabel *queryLabel;
    QLabel *adjustmentLabel;
    QLabel *normalWeightResultLabel;

    // 按钮控件
    QPushButton *calculateButton;
    QPushButton *queryConfirmButton;
    QPushButton *adjustmentBackButton;
    QPushButton *adjustmentNextButton;
    QPushButton *normalWeightCalculateButton;
    QPushButton *finishButton;
    QPushButton *returnButton;

    // 单选框控件
    QRadioButton *yesRadio;
    QRadioButton *noRadio;

    // 布局控件
    QStackedWidget *stackedWidget;
    QVBoxLayout *mainLayout;  // 添加缺失的声明

    // 数据存储
    double currentHeight;
    double currentWeight;
    double currentBMI;
    QString currentCategory;
};

#endif // BMI_CALCULATOR_H
