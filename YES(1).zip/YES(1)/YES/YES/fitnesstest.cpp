#include "fitnesstest.h"
#include "ui_fitnesstest.h"
#include <QDebug>
#include <QRegularExpression>
#include <bmi_calculator.h>
#include "widget.h"



Fitnesstest::Fitnesstest(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Fitnesstest)
{
    ui->setupUi(this);
    setupButtonGroups();
    setupConnections();
    initializeStandards();

    // 设置默认选项 - 使用UI指针访问控件
    ui->radioButton->setChecked(true);    // 男生
    ui->radioButton_3->setChecked(true);  // 大一

    // 设置项目名称标签文本
    ui->Label->setText("身高：");
    ui->Label_2->setText("体重：");
    ui->Label_3->setText("肺活量：");
    ui->Label_4->setText("坐位体前屈：");
    ui->Label_5->setText("立定跳远：");
    ui->Label_6->setText("50米跑：");
    ui->Label_7->setText("引体向上：");  // 动态标签
    ui->Label_8->setText("1000米跑："); // 动态标签

    // 设置单位标签文本
    ui->label_4->setText("厘米");
    ui->label_5->setText("千克");
    ui->label_6->setText("毫升");
    ui->label_7->setText("厘米");
    ui->label_8->setText("厘米");
    ui->label_9->setText("秒");
    ui->label_10->setText("次");     // 动态单位
    ui->label_11->setText("秒");     // 动态单位

    // 设置其他标签文本
    ui->label_2->setText("性别");
    ui->label_3->setText("年级");
    ui->label_12->setText("体测成绩：");

    // 设置单选按钮文本
    ui->radioButton->setText("男生");
    ui->radioButton_2->setText("女生");
    ui->radioButton_3->setText("大一");
    ui->radioButton_4->setText("大二");
    ui->radioButton_5->setText("大三");
    ui->radioButton_6->setText("大四");

    // 设置按钮文本
    ui->pushButton->setText("计算");
    ui->pushButton_2->setText("清空");
    ui->pushButton_3->setText("返回主菜单");

    ui->textEdit->setPlaceholderText("计算结果将显示在这里...");
    connect(ui->pushButton_3, &QPushButton::clicked, this, &Fitnesstest::on_returnToMainButton_clicked);
    updateLabelsByGender();
}

Fitnesstest::~Fitnesstest()
{
    delete ui;
    qDebug() << "Fitnesstest destroyed";
}

void Fitnesstest::on_returnToMainButton_clicked()
{
    qDebug() << "Fitnesstest页面：点击返回主菜单按钮";
    emit backToMainRequested();
}

void Fitnesstest::setupButtonGroups()
{
    // 创建性别按钮组
    genderGroup = new QButtonGroup(this);
    genderGroup->addButton(ui->radioButton);   // 男生
    genderGroup->addButton(ui->radioButton_2); // 女生

    // 创建年级按钮组
    gradeGroup = new QButtonGroup(this);
    gradeGroup->addButton(ui->radioButton_3);  // 大一
    gradeGroup->addButton(ui->radioButton_4);  // 大二
    gradeGroup->addButton(ui->radioButton_5);  // 大三
    gradeGroup->addButton(ui->radioButton_6);  // 大四
}

void Fitnesstest::setupConnections()
{
    // 连接性别单选按钮
    connect(ui->radioButton, &QRadioButton::toggled, this, &Fitnesstest::onGenderChanged);
    connect(ui->radioButton_2, &QRadioButton::toggled, this, &Fitnesstest::onGenderChanged);

    connect(ui->pushButton, &QPushButton::clicked, this, &Fitnesstest::onCalculateClicked);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &Fitnesstest::onClearClicked);

}
void Fitnesstest::updateLabelsByGender()
{
    if (ui->radioButton->isChecked()) {  // 男生
        ui->Label_7->setText("引体向上：");
        ui->Label_8->setText("1000米跑：");
        ui->label_10->setText("次");  // 引体向上单位
        ui->label_11->setText("秒");  // 1000米跑单位
    } else {  // 女生
        ui->Label_7->setText("仰卧起坐：");
        ui->Label_8->setText("800米跑：");
        ui->label_10->setText("次");  // 仰卧起坐单位
        ui->label_11->setText("秒");  // 800米跑单位
    }

    // 清空相关输入框
    ui->LineEdit_7->clear();  // 力量项目输入框
    ui->LineEdit_8->clear();  // 长跑输入框
}

void Fitnesstest::onGenderChanged()
{
    updateLabelsByGender();
}

void Fitnesstest::onBackClicked()
{
    emit backToMainRequested();
}

void Fitnesstest::onClearClicked()
{
    // 清空所有输入框
    ui->LineEdit->clear();
    ui->LineEdit_2->clear();
    ui->LineEdit_3->clear();
    ui->LineEdit_4->clear();
    ui->LineEdit_5->clear();
    ui->LineEdit_6->clear();
    ui->LineEdit_7->clear();
    ui->LineEdit_8->clear();
    ui->textEdit->clear();
}

void Fitnesstest::onCalculateClicked()
{
    // 获取用户输入
    bool ok;

    // 根据UI控件名称获取数据
    double height = ui->LineEdit->text().toDouble(&ok);  // 身高
    if (!ok || height <= 0) {
        ui->textEdit->setText("错误：请输入有效的身高（厘米）");
        return;
    }

    double weight = ui->LineEdit_2->text().toDouble(&ok);  // 体重
    if (!ok || weight <= 0) {
        ui->textEdit->setText("错误：请输入有效的体重（千克）");
        return;
    }

    int vitalCapacity = ui->LineEdit_3->text().toInt(&ok);  // 肺活量
    if (!ok || vitalCapacity <= 0) {
        ui->textEdit->setText("错误：请输入有效的肺活量（毫升）");
        return;
    }

    double sitReach = ui->LineEdit_4->text().toDouble(&ok);  // 坐位体前屈
    if (!ok) {
        ui->textEdit->setText("错误：请输入有效的坐位体前屈数值（厘米）");
        return;
    }

    double jump = ui->LineEdit_5->text().toDouble(&ok);  // 立定跳远
    if (!ok || jump <= 0) {
        ui->textEdit->setText("错误：请输入有效的立定跳远成绩（厘米）");
        return;
    }

    double run50 = ui->LineEdit_6->text().toDouble(&ok);  // 50米跑
    if (!ok || run50 <= 0) {
        ui->textEdit->setText("错误：请输入有效的50米跑成绩（秒）");
        return;
    }

    // 力量项目输入
    int strength = ui->LineEdit_7->text().toInt(&ok);  // 引体向上/仰卧起坐
    if (!ok || strength < 0) {
        ui->textEdit->setText("错误：请输入有效的上肢力量成绩（次数）");
        return;
    }

    // 长跑输入
    QString longRunText = ui->LineEdit_8->text();
    double longRun = longRunText.toDouble(&ok);
    if (!ok) {
        longRun = convertTimeToSeconds(longRunText);
        if (longRun <= 0) {
            ui->textEdit->setText("错误：请输入有效的长跑成绩（秒或分'秒格式）");
            return;
        }
    }

    // 获取性别和年级
    bool isMale = ui->radioButton->isChecked();
    QString grade;
    if (ui->radioButton_3->isChecked()) grade = "大一";
    else if (ui->radioButton_4->isChecked()) grade = "大二";
    else if (ui->radioButton_5->isChecked()) grade = "大三";
    else if (ui->radioButton_6->isChecked()) grade = "大四";

    // 计算各项得分
    double bmiScore = calculateBMIScore(height, weight, isMale);
    double vitalCapacityScore = calculateVitalCapacityScore(vitalCapacity, isMale, grade);
    double sitReachScore = calculateSitReachScore(sitReach, isMale, grade);
    double jumpScore = calculateJumpScore(jump, isMale, grade);
    double run50Score = calculateRun50Score(run50, isMale, grade);
    double longRunScore = calculateLongRunScore(longRun, isMale, grade);
    double strengthScore = calculateStrengthScore(strength, isMale, grade);

    // 计算总分
    double totalScore = (bmiScore * 0.15) + (vitalCapacityScore * 0.15) +
                        (sitReachScore * 0.10) + (jumpScore * 0.10) +
                        (run50Score * 0.20) + (longRunScore * 0.20) +
                        (strengthScore * 0.10);

    // 显示结果
    QString result = QString("体测成绩计算结果：\n\n"
                             "BMI得分：%1 分\n"
                             "肺活量得分：%2 分\n"
                             "坐位体前屈得分：%3 分\n"
                             "立定跳远得分：%4 分\n"
                             "50米跑得分：%5 分\n"
                             "%6：%7 分\n"
                             "%8：%9 分\n\n"
                             "总得分：%10 分")
                         .arg(bmiScore, 0, 'f', 1)
                         .arg(vitalCapacityScore, 0, 'f', 1)
                         .arg(sitReachScore, 0, 'f', 1)
                         .arg(jumpScore, 0, 'f', 1)
                         .arg(run50Score, 0, 'f', 1)
                         .arg(ui->Label_7->text().replace("：", ""))  // 力量项目名称
                         .arg(strengthScore, 0, 'f', 1)
                         .arg(ui->Label_8->text().replace("：", ""))  // 长跑项目名称
                         .arg(longRunScore, 0, 'f', 1)
                         .arg(totalScore, 0, 'f', 1);

    ui->textEdit->setText(result);
}

double Fitnesstest::convertTimeToSeconds(const QString& timeStr)
{
    // 处理分'秒格式，如 "3'17" 转 197秒
    QRegularExpression regex("(\\d+)['′]?(\\d+)");
    QRegularExpressionMatch match = regex.match(timeStr);

    if (match.hasMatch()) {
        int minutes = match.captured(1).toInt();
        int seconds = match.captured(2).toInt();
        return minutes * 60 + seconds;
    }

    return -1; // 转换失败
}
// 初始化评分标准数据
void Fitnesstest::initializeStandards()
{
    // BMI评分标准
    bmiStandards = {
        {"正常", 100, 17.9, 23.9, 17.2, 23.9},
        {"低体重", 80, 0, 17.8, 0, 17.1},
        {"超重", 80, 24.0, 27.9, 24.0, 27.9},
        {"肥胖", 60, 28.0, 100, 28.0, 100}
    };

    // 肺活量评分标准
    vitalCapacityStandards = {
        {100, 5040, 10000, 5140, 10000, 3400, 10000, 3450, 10000},
        {95, 4920, 5039, 5020, 5139, 3350, 3399, 3400, 3449},
        {90, 4800, 4919, 4900, 5019, 3300, 3349, 3350, 3399},
        {85, 4550, 4799, 4650, 4899, 3150, 3299, 3200, 3349},
        {80, 4300, 4549, 4400, 4649, 3000, 3149, 3050, 3199},
        {78, 4180, 4299, 4280, 4399, 2900, 2999, 2950, 3049},
        {76, 4060, 4179, 4160, 4279, 2800, 2899, 2850, 2949},
        {74, 3940, 4059, 4040, 4159, 2700, 2799, 2750, 2849},
        {72, 3820, 3939, 3920, 4039, 2600, 2699, 2650, 2749},
        {70, 3700, 3819, 3800, 3919, 2500, 2599, 2550, 2649},
        {68, 3580, 3699, 3680, 3799, 2400, 2499, 2450, 2549},
        {66, 3460, 3579, 3560, 3679, 2300, 2399, 2350, 2449},
        {64, 3340, 3459, 3440, 3559, 2200, 2299, 2250, 2349},
        {62, 3220, 3339, 3320, 3439, 2100, 2199, 2150, 2249},
        {60, 3100, 3219, 3200, 3319, 2000, 2099, 2050, 2149},
        {50, 2940, 3099, 3030, 3199, 1960, 1999, 2010, 2049},
        {40, 2780, 2939, 2860, 3029, 1920, 1959, 1970, 2009},
        {30, 2620, 2779, 2690, 2859, 1880, 1919, 1930, 1969},
        {20, 2460, 2619, 2520, 2689, 1840, 1879, 1890, 1929},
        {10, 2300, 2459, 2350, 2519, 1800, 1839, 1850, 1889}
    };

    // 坐位体前屈评分标准
    sitReachStandards = {
        {100, 24.9, 100, 25.1, 100, 25.8, 100, 26.3, 100},
        {95, 23.1, 24.8, 23.3, 25.0, 24.0, 25.7, 24.4, 26.2},
        {90, 21.3, 23.0, 21.5, 23.2, 22.2, 23.9, 22.4, 24.3},
        {85, 19.5, 21.2, 19.9, 21.4, 20.6, 22.1, 21.0, 22.3},
        {80, 17.7, 19.4, 18.2, 19.8, 19.0, 20.5, 19.5, 20.9},
        {78, 16.3, 17.6, 16.8, 18.1, 17.7, 18.9, 18.2, 19.4},
        {76, 14.9, 16.2, 15.4, 16.7, 16.4, 17.6, 16.9, 18.1},
        {74, 13.5, 14.8, 14.0, 15.3, 15.1, 16.3, 15.6, 16.8},
        {72, 12.1, 13.4, 12.6, 13.9, 13.8, 15.0, 14.3, 15.5},
        {70, 10.7, 12.0, 11.2, 12.5, 12.5, 13.7, 13.0, 14.2},
        {68, 9.3, 10.6, 9.8, 11.1, 11.2, 12.4, 11.7, 12.9},
        {66, 7.9, 9.2, 8.4, 9.7, 9.9, 11.1, 10.4, 11.6},
        {64, 6.5, 7.8, 7.0, 8.3, 8.6, 9.8, 9.1, 10.3},
        {62, 5.1, 6.4, 5.6, 6.9, 7.3, 8.5, 7.8, 9.0},
        {60, 3.7, 5.0, 4.2, 5.5, 6.0, 7.2, 6.5, 7.7},
        {50, 2.7, 3.6, 3.2, 4.1, 5.2, 5.9, 5.7, 6.4},
        {40, 1.7, 2.6, 2.2, 3.1, 4.4, 5.1, 4.9, 5.6},
        {30, 0.7, 1.6, 1.2, 2.1, 3.6, 4.3, 4.1, 4.8},
        {20, -0.3, 0.6, 0.2, 1.1, 2.8, 3.5, 3.3, 4.0},
        {10, -1.3, -0.4, -0.8, 0.1, 2.0, 2.7, 2.5, 3.2}
    };

    // 立定跳远评分标准
    jumpStandards = {
        {100, 273, 300, 275, 300, 207, 250, 208, 250},
        {95, 268, 272, 270, 274, 201, 206, 202, 207},
        {90, 263, 267, 265, 269, 195, 200, 196, 201},
        {85, 256, 262, 258, 264, 188, 194, 189, 195},
        {80, 248, 255, 250, 257, 181, 187, 182, 188},
        {78, 244, 247, 246, 249, 178, 180, 179, 181},
        {76, 240, 243, 242, 245, 175, 177, 176, 178},
        {74, 236, 239, 238, 241, 172, 174, 173, 175},
        {72, 232, 235, 234, 237, 169, 171, 170, 172},
        {70, 228, 231, 230, 233, 166, 168, 167, 169},
        {68, 224, 227, 226, 229, 163, 165, 164, 166},
        {66, 220, 223, 222, 225, 160, 162, 161, 163},
        {64, 216, 219, 218, 221, 157, 159, 158, 160},
        {62, 212, 215, 214, 217, 154, 156, 155, 157},
        {60, 208, 211, 210, 213, 151, 153, 152, 154},
        {50, 203, 207, 205, 209, 146, 150, 147, 151},
        {40, 198, 202, 200, 204, 141, 145, 142, 146},
        {30, 193, 197, 195, 199, 136, 140, 137, 141},
        {20, 188, 192, 190, 194, 131, 135, 132, 136},
        {10, 183, 187, 185, 189, 126, 130, 127, 131}
    };

    // 50米跑评分标准
    run50Standards = {
        {100, 0,   6.7,  0,   6.6,  0,   7.5,  0,   7.4},
        {95,  6.7, 6.8,  6.6, 6.7,  7.5, 7.6,  7.4, 7.5},
        {90,  6.8, 6.9,  6.7, 6.8,  7.6, 7.7,  7.5, 7.6},
        {85,  6.9, 7.0,  6.8, 6.9,  7.7, 8.0,  7.6, 7.9},
        {80,  7.0, 7.1,  6.9, 7.0,  8.0, 8.3,  7.9, 8.2},
        {78,  7.1, 7.3,  7.0, 7.2,  8.3, 8.5,  8.2, 8.4},
        {76,  7.3, 7.5,  7.2, 7.4,  8.5, 8.7,  8.4, 8.6},
        {74,  7.5, 7.7,  7.4, 7.6,  8.7, 8.9,  8.6, 8.8},
        {72,  7.7, 7.9,  7.6, 7.8,  8.9, 9.1,  8.8, 9.0},
        {70,  7.9, 8.1,  7.8, 8.0,  9.1, 9.3,  9.0, 9.2},
        {68,  8.1, 8.3,  8.0, 8.2,  9.3, 9.5,  9.2, 9.4},
        {66,  8.3, 8.5,  8.2, 8.4,  9.5, 9.7,  9.4, 9.6},
        {64,  8.5, 8.7,  8.4, 8.6,  9.7, 9.9,  9.6, 9.8},
        {62,  8.7, 8.9,  8.6, 8.8,  9.9, 10.1, 9.8, 10.0},
        {60,  8.9, 9.1,  8.8, 9.0,  10.1, 10.3, 10.0, 10.2},
        {50,  9.1, 9.3,  9.0, 9.2,  10.3, 10.5, 10.2, 10.4},
        {40,  9.3, 9.5,  9.2, 9.4,  10.5, 10.7, 10.4, 10.6},
        {30,  9.5, 9.7,  9.4, 9.6,  10.7, 10.9, 10.6, 10.8},
        {20,  9.7, 9.9,  9.6, 9.8,  10.9, 11.1, 10.8, 11.0},
        {10,  9.9, 10.1, 9.8, 10.0, 11.1, 11.3, 11.0, 11.2}
    };

    // 耐力跑评分标准（时间已转换为秒）
    longRunStandards = {
        {100, 0,    197,  0,    195,  0,    198,  0,    196},
        {95,  197,  202,  195,  200,  198,  204,  196,  202},
        {90,  202,  207,  200,  205,  204,  210,  202,  208},
        {85,  207,  214,  205,  212,  210,  217,  208,  215},
        {80,  214,  222,  212,  220,  217,  224,  215,  222},
        {78,  222,  227,  220,  225,  224,  229,  222,  227},
        {76,  227,  232,  225,  230,  229,  234,  227,  232},
        {74,  232,  237,  230,  235,  234,  239,  232,  237},
        {72,  237,  242,  235,  240,  239,  244,  237,  242},
        {70,  242,  247,  240,  245,  244,  249,  242,  247},
        {68,  247,  252,  245,  250,  249,  254,  247,  252},
        {66,  252,  257,  250,  255,  254,  259,  252,  257},
        {64,  257,  262,  255,  260,  259,  264,  257,  262},
        {62,  262,  267,  260,  265,  264,  269,  262,  267},
        {60,  267,  272,  265,  270,  269,  274,  267,  272},
        {50,  272,  292,  270,  290,  274,  284,  272,  282},
        {40,  292,  312,  290,  310,  284,  294,  282,  292},
        {30,  312,  332,  310,  330,  294,  304,  292,  302},
        {20,  332,  352,  330,  350,  304,  314,  302,  312},
        {10,  352,  372,  350,  370,  314,  324,  312,  322}
    };

    // 在initializeStandards函数中修正力量项目标准

    // 引体向上评分标准（男生）
    pullUpStandards = {
        {100, 19, 20, 0, 0},
        {95,  18, 19, 0, 0},
        {90,  17, 18, 0, 0},
        {85,  16, 17, 0, 0},
        {80,  15, 16, 0, 0},
        {76,  14, 15, 0, 0},
        {72,  13, 14, 0, 0},
        {68,  12, 13, 0, 0},
        {64,  11, 12, 0, 0},
        {60,  10, 11, 0, 0},
        {50,  9,  10, 0, 0},
        {40,  8,  9,  0, 0},
        {30,  7,  8,  0, 0},
        {20,  6,  7,  0, 0},
        {10,  5,  6,  0, 0}
    };

    // 仰卧起坐评分标准（女生）
    sitUpStandards = {
        {100, 0, 0, 56, 57},
        {95,  0, 0, 54, 55},
        {90,  0, 0, 52, 53},
        {85,  0, 0, 49, 50},
        {80,  0, 0, 46, 47},
        {78,  0, 0, 44, 45},
        {76,  0, 0, 42, 43},
        {74,  0, 0, 40, 41},
        {72,  0, 0, 38, 39},
        {70,  0, 0, 36, 37},
        {68,  0, 0, 34, 35},
        {66,  0, 0, 32, 33},
        {64,  0, 0, 30, 31},
        {62,  0, 0, 28, 29},
        {60,  0, 0, 26, 27},
        {50,  0, 0, 24, 25},
        {40,  0, 0, 22, 23},
        {30,  0, 0, 20, 21},
        {20,  0, 0, 18, 19},
        {10,  0, 0, 16, 17}
    };
}

// 关键的计算函数实现
double Fitnesstest::calculateBMIScore(double height, double weight, bool isMale)
{
    double heightM = height / 100.0; // 厘米转米
    double bmi = weight / (heightM * heightM);

    for (const BMIScore& standard : bmiStandards) {
        if (isMale) {
            if (bmi >= standard.maleMin && bmi <= standard.maleMax) {
                return standard.score;
            }
        } else {
            if (bmi >= standard.femaleMin && bmi <= standard.femaleMax) {
                return standard.score;
            }
        }
    }

    return 0; // 默认0分
}

double Fitnesstest::calculateVitalCapacityScore(int value, bool isMale, const QString& grade)
{
    return findScoreFromStandard(vitalCapacityStandards, value, isMale, getGradeGroup(grade), true);
}

double Fitnesstest::calculateSitReachScore(double value, bool isMale, const QString& grade)
{
    return findScoreFromStandard(sitReachStandards, value, isMale, getGradeGroup(grade), true);
}

double Fitnesstest::calculateJumpScore(double value, bool isMale, const QString& grade)
{
    return findScoreFromStandard(jumpStandards, value, isMale, getGradeGroup(grade), true);
}

double Fitnesstest::calculateRun50Score(double value, bool isMale, const QString& grade)
{
    return findScoreFromStandard(run50Standards, value, isMale, getGradeGroup(grade), false);
}

double Fitnesstest::calculateLongRunScore(double value, bool isMale, const QString& grade)
{
    // 长跑是数值越小越好，所以higherBetter参数为false
    return findScoreFromStandard(longRunStandards, value, isMale, getGradeGroup(grade), false);
}

double Fitnesstest::calculateStrengthScore(int value, bool isMale, const QString& grade)
{
    QString gradeGroup = getGradeGroup(grade);

    if (isMale) {
        // 男生做引体向上
        for (const StrengthScore& standard : pullUpStandards) {
            int threshold;
            if (gradeGroup == "12") {
                threshold = standard.maleLower12;
            } else {
                threshold = standard.maleLower34;
            }

            if (value >= threshold) {
                return standard.score;
            }
        }
    } else {
        // 女生做仰卧起坐
        for (const StrengthScore& standard : sitUpStandards) {
            int threshold;
            if (gradeGroup == "12") {
                threshold = standard.femaleLower12;
            } else {
                threshold = standard.femaleLower34;
            }

            if (value >= threshold) {
                return standard.score;
            }
        }
    }

    return 0; // 默认0分
}
// 辅助函数
QString Fitnesstest::getGradeGroup(const QString& grade)
{
    if (grade == "大一" || grade == "大二") return "12";
    else return "34";
}

double Fitnesstest::findScoreFromStandard(const QVector<ScoreStandard>& standards, double value,
                                          bool isMale, const QString& gradeGroup, bool higherBetter)
{
    for (const ScoreStandard& standard : standards) {
        double lower, upper;

        if (isMale) {
            if (gradeGroup == "12") {
                lower = standard.maleLower12;
                upper = standard.maleUpper12;
            } else {
                lower = standard.maleLower34;
                upper = standard.maleUpper34;
            }
        } else {
            if (gradeGroup == "12") {
                lower = standard.femaleLower12;
                upper = standard.femaleUpper12;
            } else {
                lower = standard.femaleLower34;
                upper = standard.femaleUpper34;
            }
        }

        if (higherBetter) {
            // 数值越大越好（如肺活量、跳远等）
            if (value >= lower && value <= upper) {
                return standard.score;
            }
        } else {
            // 数值越小越好（如跑步时间）
            if (value >= lower && (upper == 0 || value <= upper)) {
                return standard.score;
            }
        }
    }

    return 0; // 默认0分
}

int Fitnesstest::findStrengthScore(const QVector<StrengthScore>& standards, int value,
                                   bool isMale, const QString& gradeGroup)
{
    for (const StrengthScore& standard : standards) {
        int threshold;
        if (isMale) {
            threshold = (gradeGroup == "12") ? standard.maleLower12 : standard.maleLower34;
        } else {
            threshold = (gradeGroup == "12") ? standard.femaleLower12 : standard.femaleLower34;
        }

        if (value >= threshold) {
            return standard.score;
        }
    }

    return 0; // 默认0分
}


void Fitnesstest::on_pushButton_4_clicked()
{

        BMI_Calculator *pic =new BMI_Calculator();
        pic->show();
}

