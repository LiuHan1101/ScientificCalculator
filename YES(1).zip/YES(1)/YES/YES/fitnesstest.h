#ifndef FITNESSTEST_H
#define FITNESSTEST_H

#include <QWidget>
#include <QVector>
#include <QButtonGroup>

namespace Ui {
class Fitnesstest;
}

// BMI评分标准结构
struct BMIScore {
    QString level;
    int score;
    double maleMin;
    double maleMax;
    double femaleMin;
    double femaleMax;
};

// 通用评分标准结构
struct ScoreStandard {
    int score;
    double maleLower12;
    double maleUpper12;
    double maleLower34;
    double maleUpper34;
    double femaleLower12;
    double femaleUpper12;
    double femaleLower34;
    double femaleUpper34;
};

// 长跑标准结构
struct LongRunScore {
    int score;
    double male1000Lower12;  // 男生1000米大一大二下限(秒)
    double male1000Upper12;  // 男生1000米大一大二上限(秒)
    double male1000Lower34;  // 男生1000米大三大四下限(秒)
    double male1000Upper34;  // 男生1000米大三大四上限(秒)
    double female800Lower12; // 女生800米大一大二下限(秒)
    double female800Upper12; // 女生800米大一大二上限(秒)
    double female800Lower34; // 女生800米大三大四下限(秒)
    double female800Upper34; // 女生800米大三大四上限(秒)
};

// 引体向上/仰卧起坐评分标准
struct StrengthScore {
    int score;
    int maleLower12;
    int maleLower34;
    int femaleLower12;
    int femaleLower34;
};

class Fitnesstest : public QWidget
{
    Q_OBJECT

public:
    explicit Fitnesstest(QWidget *parent = nullptr);
    ~Fitnesstest();

signals:
    void backToMainRequested();

private slots:
    void onGenderChanged();
    void onCalculateClicked();
    void onClearClicked();
    void onBackClicked();
    void on_returnToMainButton_clicked();

    void on_pushButton_4_clicked();

private:
    void setupButtonGroups();
    void setupConnections();
    void initializeStandards();
    void updateLabelsByGender();

    // 计算各项得分
    double calculateBMIScore(double height, double weight, bool isMale);
    double calculateVitalCapacityScore(int value, bool isMale, const QString& grade);
    double calculateSitReachScore(double value, bool isMale, const QString& grade);
    double calculateJumpScore(double value, bool isMale, const QString& grade);
    double calculateRun50Score(double value, bool isMale, const QString& grade);
    double calculateLongRunScore(double value, bool isMale, const QString& grade);
    double calculateStrengthScore(int value, bool isMale, const QString& grade);

    // 辅助函数
    QString getGradeGroup(const QString& grade);
    double findScoreFromStandard(const QVector<ScoreStandard>& standards, double value,
                                 bool isMale, const QString& gradeGroup, bool higherBetter = true);
    int findStrengthScore(const QVector<StrengthScore>& standards, int value,
                          bool isMale, const QString& gradeGroup);

    double convertTimeToSeconds(const QString& timeStr);

private:
    Ui::Fitnesstest *ui;
    QButtonGroup *genderGroup;
    QButtonGroup *gradeGroup;


    // 评分标准数据
    QVector<BMIScore> bmiStandards;
    QVector<ScoreStandard> vitalCapacityStandards;
    QVector<ScoreStandard> sitReachStandards;
    QVector<ScoreStandard> jumpStandards;
    QVector<ScoreStandard> run50Standards;
    QVector<ScoreStandard> longRunStandards;
    QVector<StrengthScore> pullUpStandards;
    QVector<StrengthScore> sitUpStandards;
};

#endif // FITNESSTEST_H
