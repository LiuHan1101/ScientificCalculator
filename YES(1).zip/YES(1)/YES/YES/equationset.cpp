#include "equationset.h"
#include "ui_equationset.h"
#include <QMessageBox>
#include <QDebug>

Equationset::Equationset(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Equationset)
{
    ui->setupUi(this);

    // 设置固定大小
    this->setFixedSize(650, 600);


    // 连接信号槽 - 使用新的对象名
    connect(ui->solve, &QPushButton::clicked, this, &Equationset::on_solve_clicked);
    connect(ui->clear, &QPushButton::clicked, this, &Equationset::on_clear_clicked);
    connect(ui->returnToEquationButton, &QPushButton::clicked, this, &Equationset::on_returnToEquationButton_clicked);
    connect(ui->returnToMainButton, &QPushButton::clicked, this, &Equationset::on_returnToMainButton_clicked);

    qDebug() << "Equationset页面初始化完成";
}

Equationset::~Equationset()
{
    delete ui;
}

void Equationset::on_solve_clicked()
{
    qDebug() << "点击求解按钮";

    // 获取输入值
    QString a1Text = ui->lineEdit->text();    // a1
    QString b1Text = ui->lineEdit_2->text();  // b1
    QString c1Text = ui->lineEdit_3->text();  // c1
    QString a2Text = ui->lineEdit_4->text();  // a2
    QString b2Text = ui->lineEdit_5->text();  // b2
    QString c2Text = ui->lineEdit_6->text();  // c2

    // 验证输入
    if (a1Text.isEmpty() || b1Text.isEmpty() || c1Text.isEmpty() ||
        a2Text.isEmpty() || b2Text.isEmpty() || c2Text.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请输入所有系数的值");
        return;
    }

    bool ok1, ok2, ok3, ok4, ok5, ok6;
    double a1 = a1Text.toDouble(&ok1);
    double b1 = b1Text.toDouble(&ok2);
    double c1 = c1Text.toDouble(&ok3);
    double a2 = a2Text.toDouble(&ok4);
    double b2 = b2Text.toDouble(&ok5);
    double c2 = c2Text.toDouble(&ok6);

    if (!ok1 || !ok2 || !ok3 || !ok4 || !ok5 || !ok6) {
        QMessageBox::warning(this, "输入错误", "请输入有效的数字");
        return;
    }

    // 计算行列式
    double D = a1 * b2 - a2 * b1;
    double Dx = c1 * b2 - c2 * b1;
    double Dy = a1 * c2 - a2 * c1;

    QString resultText;

    if (D == 0) {
        if (Dx == 0 && Dy == 0) {
            resultText = QString("方程组:\n"
                                 "%1x + %2y = %3\n"
                                 "%4x + %5y = %6\n\n"
                                 "行列式 D = %7\n"
                                 "解: 无穷多解 (方程组相关)")
                             .arg(a1).arg(b1).arg(c1)
                             .arg(a2).arg(b2).arg(c2)
                             .arg(D, 0, 'f', 4);
        } else {
            resultText = QString("方程组:\n"
                                 "%1x + %2y = %3\n"
                                 "%4x + %5y = %6\n\n"
                                 "行列式 D = %7\n"
                                 "解: 无解 (方程组矛盾)")
                             .arg(a1).arg(b1).arg(c1)
                             .arg(a2).arg(b2).arg(c2)
                             .arg(D, 0, 'f', 4);
        }
    } else {
        double x = Dx / D;
        double y = Dy / D;

        resultText = QString("方程组:\n"
                             "%1x + %2y = %3\n"
                             "%4x + %5y = %6\n\n"
                             "行列式 D = %7\n"
                             "Dx = %8, Dy = %9\n"
                             "解: x = %10, y = %11")
                         .arg(a1).arg(b1).arg(c1)
                         .arg(a2).arg(b2).arg(c2)
                         .arg(D, 0, 'f', 4)
                         .arg(Dx, 0, 'f', 4)
                         .arg(Dy, 0, 'f', 4)
                         .arg(x, 0, 'f', 4)
                         .arg(y, 0, 'f', 4);

        qDebug() << "计算完成: x =" << x << "y =" << y;
    }

    ui->result->setText(resultText);
}

void Equationset::on_clear_clicked()
{
    qDebug() << "点击清空按钮";

    // 清空所有输入和结果
    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
    ui->lineEdit_3->clear();
    ui->lineEdit_4->clear();
    ui->lineEdit_5->clear();
    ui->lineEdit_6->clear();
    ui->result->clear();
}

void Equationset::on_returnToEquationButton_clicked()
{
    qDebug() << "Equationset页面：点击返回方程选择按钮";
    emit returnToEquationRequested();
    this->hide();
}

void Equationset::on_returnToMainButton_clicked()
{
    qDebug() << "Equationset页面：点击返回主菜单按钮";
    emit returnToMainRequested();
    this->hide();
}
