#ifndef CALCULATE_H
#define CALCULATE_H

#include <QWidget>
#include <QStackedWidget>

class basiccalculate;
class CalculatePlus;

namespace Ui {
class calculate;
}

class calculate : public QWidget
{
    Q_OBJECT

public:
    explicit calculate(QWidget *parent = nullptr);
    ~calculate();

signals:
    void backToMainRequested();

private slots:
    void on_radioButton_2_clicked();
    void on_radioButton_3_clicked();
    void showCalculatePage();
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::calculate *ui;
    QStackedWidget *subPageStack;  // 子页面堆叠窗口
    basiccalculate *basicCalcPage;
    CalculatePlus *calcPlusPage;
};


#endif // CALCULATE_H
