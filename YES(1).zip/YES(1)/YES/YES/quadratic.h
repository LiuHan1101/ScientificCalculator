#ifndef QUADRATIC_H
#define QUADRATIC_H

#include <QWidget>

namespace Ui {
class Quadratic;
}

class Quadratic : public QWidget
{
    Q_OBJECT

public:
    explicit Quadratic(QWidget *parent = nullptr);
    ~Quadratic();

signals:
    void returnToEquationRequested();
    void returnToMainRequested();

private slots:
    void on_pushButton_clicked();  // 求解按钮
    void on_pushButton_2_clicked(); // 清空按钮
    void on_pushButton_3_clicked(); // 返回方程选择按钮
    void on_pushButton_4_clicked(); // 返回主菜单按钮

private:
    Ui::Quadratic *ui;


};

#endif // QUADRATIC_H
