#include "widget.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);  // 创建应用程序对象
    Widget w;                    // 创建主窗口
    w.show();                    // 显示窗口
    return a.exec();             // 进入事件循环
}
