#ifndef GPA_H
#define GPA_H

#include <QWidget>
#include <QTableWidgetItem>

namespace Ui {
class Gpa;
}

class Gpa : public QWidget
{
    Q_OBJECT

public:
    explicit Gpa(QWidget *parent = nullptr);
    ~Gpa();

signals:
    void backToMainRequested();

private slots:
    void on_pushButton_clicked();
    void on_addNewCourse_clicked();
    void on_calculateAllGPA_clicked();
    void on_calculateRequiredGPA_clicked();  // 计算必修课平均绩点
    void on_calculateElectiveGPA_clicked();
    void on_clearAll_clicked();
    void on_returnToMain_clicked();

private:
    Ui::Gpa *ui;
    double calculateGradePoint(double grade, QString &level);
    void updateCourseCount();
    void clearInputFields();
    void initializeTable();
    void calculateSpecificGPA(const QString &courseType);
};

#endif // GPA_H
