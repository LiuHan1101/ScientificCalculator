#ifndef WIDGET_H
#define WIDGET_H

#include "qboxlayout.h"
#include "qradiobutton.h"
#include "qstackedwidget.h"
#include <QWidget>

// 前向声明类
class Equation;
class Fitnesstest;
class Gpa;
class BMI_Calculator;
class PDPtest;
class CalculatePlus;

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    // UI初始化相关方法
    void initializeUI();
    void setWindowProperties();
    void createMainLayout();
    void createAllPages();

    // 主菜单创建方法
    void createMainMenu();
    void createTitleLabel(QVBoxLayout *layout);
    void createModeSelectionGroup(QVBoxLayout *layout);
    QString getGroupBoxStyle();
    QString getRadioButtonStyle();
    void createRadioButtons(QVBoxLayout *modeLayout);
    void connectRadioButtons(QRadioButton *radioButtons[]);

    // 功能页面创建方法
    void createArithmeticPage();
    void createEquationPage();
    void createGPAPage();
    void createFitnessPage();
    void createBMIPage();
    void createPDPPage();

    // 通用工具方法
    void setupPageConnections(QWidget *page);
    void switchToPage(QWidget *page, const QString &pageName);

private slots:
    // 页面切换槽函数
    void onArithmeticClicked();
    void onEquationClicked();
    void onGPAClicked();
    void onFitnessClicked();
    void onBMIClicked();
    void onPDPClicked();
    void switchToMainMenu();

private:
    Ui::Widget *ui;

    // 堆栈窗口管理
    QStackedWidget *stackedWidget;

    // 页面指针
    QWidget *mainMenuPage;
    CalculatePlus *arithmeticPage;
    BMI_Calculator *bmiPage;
    PDPtest *pdpPage;
    Equation *equationPage;
    Fitnesstest *fitnessPage;
    Gpa *gpaPage;
};

#endif // WIDGET_H
